JAVA INTERVIEW STUDY PACK

Open index.html for the searchable guide, or Java-Interview-Guide.md in a text editor.
Read in this order:
1 Concepts and methods, with short input/output scenarios
2 Coding questions with their answers and detailed explanations
3 Appendices

Each programs/*/Main.java is an independent runnable example. Use one at a time in OneCompiler.
The HTML blotter examples require jsoup, included in lib. Other examples use only the standard library.
Run all completed examples on macOS/Linux with Java 17+: sh run-all.sh
practice/onecompiler contains the saved exercise with the calculation TODO and its Maven setup.
Questions with no earlier worked answer are clearly labelled in the guide.
The original jsoup jar includes its licence; see lib/jsoup-1.24.1.jar.
