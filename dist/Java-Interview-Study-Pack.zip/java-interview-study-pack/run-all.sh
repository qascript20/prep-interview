#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p .build
for example in programs/*/Main.java; do
    folder=$(dirname "$example")
    name=$(basename "$folder")
    mkdir -p ".build/$name"
    printf '\n%s\n' "$name"
    javac --release 17 -cp 'lib/*' -d ".build/$name" "$example"
    java -cp ".build/$name:lib/*" Main
done
printf '\n%s\n' '12-html-blotter original parser checks'
mkdir -p .build/original-blotter
javac --release 17 -cp 'lib/*' -d .build/original-blotter programs/12-html-blotter/TradeBlotter.java programs/12-html-blotter/BlotterChecks.java
cd programs/12-html-blotter
java -cp '../../.build/original-blotter:../../lib/*' BlotterChecks
