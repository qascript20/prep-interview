# Java interview study guide

Java 17+ · Trading examples · Updated 15 November 2026

Study in order: **combined concepts and methods → coding questions with embedded answers**. Each available answer and explanation appears directly below its question. The appendices contain setup instructions, common errors and interview revision.

## Contents

- [Part 1 Concepts and methods](#part-1-concepts-and-methods)
  - [1.01 Objects constructors and immutability](#1-01-objects-constructors-and-immutability)
  - [1.02 Equality null handling and Object utility methods](#1-02-equality-null-handling-and-object-utility-methods)
  - [1.03 BigDecimal financial arithmetic and rounding](#1-03-bigdecimal-financial-arithmetic-and-rounding)
  - [1.04 Collections lists sets queues and copies](#1-04-collections-lists-sets-queues-and-copies)
  - [1.05 Maps sorted maps and comparators](#1-05-maps-sorted-maps-and-comparators)
  - [1.06 Streams pipelines filtering mapping and ordering](#1-06-streams-pipelines-filtering-mapping-and-ordering)
  - [1.07 Collectors grouping and financial reductions](#1-07-collectors-grouping-and-financial-reductions)
  - [1.08 Threads executors futures and lifecycle management](#1-08-threads-executors-futures-and-lifecycle-management)
  - [1.09 Atomic updates concurrent maps and bounded queues](#1-09-atomic-updates-concurrent-maps-and-bounded-queues)
  - [1.10 ThreadLocal context and CompletableFuture composition](#1-10-threadlocal-context-and-completablefuture-composition)
- [Part 2 Coding questions and answers](#part-2-coding-questions-and-answers)
  - [2.01 Find duplicate trade IDs in second occurrence order](#2-01-find-duplicate-trade-ids-in-second-occurrence-order)
  - [2.02 Duplicate IDs using Streams](#2-02-duplicate-ids-using-streams)
  - [2.03 Validate a trading order and return all errors](#2-03-validate-a-trading-order-and-return-all-errors)
  - [2.04 Calculate total trade quantity by symbol](#2-04-calculate-total-trade-quantity-by-symbol)
  - [2.05 Find the trade with the highest quantity](#2-05-find-the-trade-with-the-highest-quantity)
  - [2.06 Find trades missing from actual results](#2-06-find-trades-missing-from-actual-results)
  - [2.07 Check a palindrome after cleaning the string](#2-07-check-a-palindrome-after-cleaning-the-string)
  - [2.08 Check a palindrome with constant extra space](#2-08-check-a-palindrome-with-constant-extra-space)
  - [2.09 Create an immutable Order with validation and notional](#2-09-create-an-immutable-order-with-validation-and-notional)
  - [2.10 Deduplicate orders using equals and hashCode](#2-10-deduplicate-orders-using-equals-and-hashcode)
  - [2.11 Parse an HTML blotter and calculate executed BUY notional](#2-11-parse-an-html-blotter-and-calculate-executed-buy-notional)
  - [2.12 Reusable HTML parser with header mapping](#2-12-reusable-html-parser-with-header-mapping)
  - [2.13 Quantity mismatches between maps](#2-13-quantity-mismatches-between-maps)
  - [2.14 Reconcile prices and quantities between UI and API objects](#2-14-reconcile-prices-and-quantities-between-ui-and-api-objects)
  - [2.15 Find a cell when table columns move](#2-15-find-a-cell-when-table-columns-move)
  - [2.16 Calculate executed BUY notional by symbol](#2-16-calculate-executed-buy-notional-by-symbol)
  - [2.17 Calculate volume weighted average execution price](#2-17-calculate-volume-weighted-average-execution-price)
  - [2.18 Find the largest executed trades](#2-18-find-the-largest-executed-trades)
  - [2.19 Reconcile two complete trade snapshots](#2-19-reconcile-two-complete-trade-snapshots)
  - [2.20 Deduplicate execution events](#2-20-deduplicate-execution-events)
  - [2.21 Maintain best bid and ask](#2-21-maintain-best-bid-and-ask)
  - [2.22 Fix a concurrent trade counter](#2-22-fix-a-concurrent-trade-counter)
  - [2.23 Prevent stale market data updates](#2-23-prevent-stale-market-data-updates)
  - [2.24 Run trading risk checks concurrently](#2-24-run-trading-risk-checks-concurrently)
- [Part 3 Appendices](#part-3-appendices)
  - [3.01 Running the examples and using the study pack](#3-01-running-the-examples-and-using-the-study-pack)
  - [3.02 Compiler errors and collection pitfalls](#3-02-compiler-errors-and-collection-pitfalls)
  - [3.03 Oral interview questions and short answers](#3-03-oral-interview-questions-and-short-answers)
  - [3.04 Other prompts preparation plan and role context](#3-04-other-prompts-preparation-plan-and-role-context)
  - [3.05 Reference links](#3-05-reference-links)

## Part 1 Concepts and methods

Study one topic at a time. Each chapter combines its core concepts and method reference with short scenarios that show the input, Java code, output and reason for the result. These short Java snippets belong inside a main method; standard Java imports are assumed. Complete runnable programs for the worked coding answers are included in the download.


### 1.01 Objects constructors and immutability

**Concept**

An object is an instance with state and behaviour. Object, in java.lang, is the root class inherited by Java classes. Objects, in java.util, is a separate utility class containing static methods such as Objects.equals() and Objects.requireNonNull(). Order and Trade are application domain types. The plural utility class does not create trading objects for you.

| Concept | Meaning | Trading or automation example |
|---|---|---|
| Encapsulation | Control access to state through a class's API | Private order fields and validated construction |
| Abstraction | Expose a useful contract without its implementation details | A RiskCheck interface with an evaluate method |
| Inheritance | A class extends another class and inherits accessible behaviour | A specialised result type; avoid inheritance solely to share test state |
| Polymorphism | An interface or superclass reference can invoke an implementation's overridden method | Different RiskCheck implementations behind the same interface |
| Composition | An object delegates work to collaborators it holds | A test service composed of a client, parser and comparator |
| Overloading | Same method name with different parameter lists | findOrder(String id) and findOrder(long sequence) |
| Overriding | A subtype supplies an implementation of an inherited instance method | Order.equals(Object) |

Overloading is resolved from compile-time types. Overridden instance methods use runtime dispatch. Static methods are hidden rather than overridden; constructors are not inherited. An interface describes a contract and can also declare default and static methods. An abstract class can hold instance state and constructors as well as abstract and concrete methods. A class can implement several interfaces but extend only one class.

**Constructors and this**

A constructor initialises a new object and has the same name as its class, with no return type. In this.symbol = symbol, this.symbol is the object field and symbol is the parameter. A static method has no current object represented by this. A final field cannot be reassigned after initialisation; a final reference alone does not make a mutable object immutable.

**Encapsulation and safe object design**

Java passes arguments by value. For objects, that value is a reference: a method can mutate a shared mutable object, but reassigning its parameter does not reassign the caller's variable. == compares reference identity for ordinary objects; use appropriate value equality for content.

A record automatically supplies a canonical constructor, component accessors, equals(), hashCode() and toString(). Its default equality uses every component. A record containing BigDecimal therefore inherits scale-sensitive BigDecimal equality unless you define a different domain rule. A record containing a mutable List is not deeply immutable merely because the record's reference fields are final.

In a defensive-copy constructor, storing an unmodifiable copy protects the saved list structure from changes through the input list. This is a shallow copy. It is sufficient for immutable String elements; mutable elements require an appropriate deeper-copy strategy. List.copyOf() rejects null elements.

**Exceptions and resource ownership**

Use IllegalArgumentException for an invalid argument contract, and understand that requireNonNull() throws NullPointerException. Checked exceptions must be handled or declared; unchecked exceptions are RuntimeException subtypes. Try-with-resources closes AutoCloseable resources in reverse declaration order. A return inside finally can suppress an exception, so avoid that pattern. A static shared test object can retain data across tests even when each test's local variables have disappeared.

**Scenario Create a trade**

A trade must retain the symbol supplied when the object is constructed.

**Input**

```text
Symbol supplied to the constructor: AAPL
```

**Java**

```java
final class Trade {
    private final String symbol;
    Trade(String symbol) { this.symbol = symbol; }
    String symbol() { return symbol; }
}
Trade trade = new Trade("AAPL");
System.out.println(trade.symbol());
```

**Output**

```text
AAPL
```

**Why this happens**

The constructor stores the parameter on that particular object. The getter reads the stored field.

**Scenario Reject an invalid quantity**

An order constructor should reject a zero or negative quantity before assigning fields.

**Input**

```text
Quantity: -1
```

**Java**

```java
try {
    int quantity = -1;
    if (quantity <= 0) {
        throw new IllegalArgumentException("Quantity must be positive");
    }
} catch (IllegalArgumentException error) {
    System.out.println(error.getMessage());
}
```

**Output**

```text
Quantity must be positive
```

**Why this happens**

The guard fails immediately. Use quantity < 0 instead if the contract permits zero.

**Scenario Protect order tags from caller changes**

A caller changes its original list after an immutable order snapshot has copied it.

**Input**

```text
Original tags: [BUY]
Caller later appends: CHANGED
```

**Java**

```java
List<String> input = new ArrayList<>(List.of("BUY"));
List<String> stored = List.copyOf(input);
input.add("CHANGED");
System.out.println(input);
System.out.println(stored);
```

**Output**

```text
[BUY, CHANGED]
[BUY]
```

**Why this happens**

List.copyOf creates an unmodifiable structural snapshot. It is a shallow copy; mutable elements would need their own copying policy.


### 1.02 Equality null handling and Object utility methods

**Concept**

Reference identity asks whether two references point to the same object. Logical equality asks whether two values meet the domain equality rule. Hash-based collections require equal objects to have equal hashes. Matching hashes alone do not prove equality.

**Object methods**

| Method | Purpose | Interview point |
|---|---|---|
| equals(Object) | Logical equality when overridden | The inherited implementation uses identity |
| hashCode() | Hash value used by hash collections | Equal objects need equal hashes; collisions are permitted |
| toString() | Text representation | Make diagnostics useful without exposing secrets |
| getClass() | Runtime class | Understand exact-type checks versus instanceof |
| wait() and timed wait | Wait on this object's monitor | Own the monitor; recheck a condition in a loop |
| notify() / notifyAll() | Wake monitor waiters | Waking does not transfer the lock immediately |
| clone() | Cloning mechanism when supported | Not a general public deep-copy operation |

Know equals() as an equivalence relation: reflexive, symmetric, transitive and consistent, with false for null. Do not use a mutable field in equality or hashing while the object is stored in a HashMap or HashSet. A hash code is neither a unique identifier nor a guaranteed memory address. Prefer explicit copy constructors or factories over introducing clone() in a new domain design. Finalization is deprecated for removal and should not be used for executor or browser cleanup.

**Objects utility methods**

| Method | Example | Key behaviour |
|---|---|---|
| equals(a, b) | Objects.equals(orderId, otherId) | Null-safe equality |
| hash(values...) | Objects.hash(orderId) | Hash multiple equality fields consistently |
| hashCode(value) | Objects.hashCode(orderId) | One object's hash or zero for null |
| requireNonNull(value, message) | Objects.requireNonNull(trade, "trade") | Throws NullPointerException |
| requireNonNullElse(value, fallback) | Objects.requireNonNullElse(symbol, "UNKNOWN") | Non-null fallback when value is null |
| requireNonNullElseGet(value, supplier) | Objects.requireNonNullElseGet(value, factory) | Fallback is produced only if needed |
| isNull(value) / nonNull(value) | stream.filter(Objects::nonNull) | Useful predicates when the data contract permits filtering nulls |
| toString(value, fallback) | Objects.toString(value, "missing") | Null-safe diagnostic text |
| deepEquals(a, b) | Objects.deepEquals(array1, array2) | Handles array-content comparison; not arbitrary recursive domain equality |

Objects.hash(id) and Objects.hashCode(id) need not return the same number. Choose a consistent implementation; equal instances must use the same rule. Filtering away invalid records is a business decision, not an automatic alternative to validation.

**Null blank and short circuiting**

null means there is no String object. isBlank() checks an existing string and returns true when it is empty or contains only Java-defined whitespace.

| Value | value == null | value.isBlank() |
|---|---|---|
| null | true | Throws NullPointerException |
| "" | false | true |
| "   " | false | true |
| "\t\n" | false | true |
| "T1" | false | false |
| " T1 " | false | false |

Java evaluates || from left to right and skips the right expression if the left is true. This protects the method call when tradeId is null. In a price check, price == null || price.compareTo(BigDecimal.ZERO) <= 0 rejects a missing, zero or negative price.

Changing that price check to && changes its meaning and breaks null safety: if price is null, the right expression is evaluated and throws NullPointerException; if price is non-null, the left expression is false and the price comparison is skipped.

**Scenario Compare optional identifiers safely**

An optional API identifier is missing; compare it without calling a method on null.

**Input**

```text
first = null
second = T1
```

**Java**

```java
String first = null;
String second = "T1";
System.out.println(Objects.equals(first, second));
System.out.println(Objects.equals(first, null));
System.out.println(Objects.requireNonNullElse(first, "UNKNOWN"));
System.out.println(Objects.toString(first, "missing"));
```

**Output**

```text
false
true
UNKNOWN
missing
```

**Why this happens**

Objects.equals handles nulls. requireNonNullElse supplies a fallback for null, not for a blank string. toString supplies readable diagnostic text.

**Scenario Validate null and blank IDs**

Reject missing or blank trade IDs while accepting an actual ID.

**Input**

```text
IDs: null, empty string, T1
```

**Java**

```java
for (String id : Arrays.asList(null, "", "T1")) {
    System.out.println(id == null || id.isBlank());
}
```

**Output**

```text
true
true
false
```

**Why this happens**

When id is null, the left side of OR is true, so isBlank is skipped. This prevents NullPointerException.

**Scenario Remove duplicate value objects**

A trade-ID value object defines identity using its single record component.

**Input**

```text
Trade IDs: T1, T1, T2
```

**Java**

```java
record TradeId(String value) {}
TradeId first = new TradeId("T1");
TradeId duplicate = new TradeId("T1");
System.out.println(first == duplicate);
System.out.println(first.equals(duplicate));
System.out.println(new HashSet<>(List.of(first, duplicate, new TradeId("T2"))).size());
```

**Output**

```text
false
true
2
```

**Why this happens**

The two T1 objects have different identities, but record equality and hashing use their component value. HashSet therefore stores one T1 and one T2.


### 1.03 BigDecimal financial arithmetic and rounding

**Concept**

BigDecimal represents arbitrary-precision decimal values with explicit scale and rounding control. Construct prices directly from strings, such as new BigDecimal("100.25"). Constructing from a double can preserve its binary floating-point approximation.

Common methods are add(), subtract(), multiply(), divide(), compareTo(), signum(), setScale(), scale(), precision() and toPlainString(). For 10.50, scale is 2 and precision is 4. Scale can be negative for other representations; do not treat it as an unsigned count in every possible BigDecimal.

Arithmetic returns a value without changing the original object. total.add(price) discards that returned result; total = total.add(price) keeps it. Exact division such as 1 / 3 throws ArithmeticException unless an appropriate precision or rounding rule is supplied. In divide(divisor, 2, HALF_UP), 2 specifies two decimal places.

equals() compares numeric value and scale. compareTo() compares numerical value. Consequently 10.0 and 10.00 are unequal under equals() but compareTo() returns zero. ZERO, ONE and TEN are useful constants.

**Important methods**

| Method | Meaning |
|---|---|
| new BigDecimal(String) | Construct directly from decimal text |
| BigDecimal.valueOf(long) | Convert an integral quantity |
| add(), subtract(), multiply() | Return the arithmetic result without changing the original value |
| divide(divisor) | Exact division when the result is representable |
| divide(divisor, scale, roundingMode) | Apply an explicit division and rounding contract |
| compareTo(), equals() | Numeric comparison versus value-and-scale equality |
| signum() | Negative, zero or positive |
| setScale(), scale(), precision() | Set representation scale or inspect scale and significant digits |
| toPlainString() | Produce text without exponent notation |

**Scenario Calculate order notional**

An executed order has a decimal price and an integral quantity.

**Input**

```text
Price: 100.25
Quantity: 10
```

**Java**

```java
BigDecimal price = new BigDecimal("100.25");
int quantity = 10;
BigDecimal notional = price.multiply(BigDecimal.valueOf(quantity));
System.out.println(notional.toPlainString());
```

**Output**

```text
1002.50
```

**Why this happens**

Convert the quantity to BigDecimal, multiply and keep the returned result. No binary floating-point arithmetic is introduced.

**Scenario Keep the updated total**

A running notional total must retain the result of addition.

**Input**

```text
Initial total: 0
Notional to add: 100.25
```

**Java**

```java
BigDecimal total = BigDecimal.ZERO;
BigDecimal notional = new BigDecimal("100.25");
total.add(notional);
System.out.println(total);
total = total.add(notional);
System.out.println(total);
```

**Output**

```text
0
100.25
```

**Why this happens**

The first result is discarded because BigDecimal is immutable. The assignment keeps the new value.

**Scenario Compare representation and round a ratio**

Two systems use different decimal scales, and a report requires a rounded one-third ratio.

**Input**

```text
Values: 10.0 and 10.00
Ratio: 1 / 3, two decimal places, HALF_UP
```

**Java**

```java
BigDecimal first = new BigDecimal("10.0");
BigDecimal second = new BigDecimal("10.00");
System.out.println(first.equals(second));
System.out.println(first.compareTo(second) == 0);
System.out.println(BigDecimal.ONE.divide(new BigDecimal("3"), 2, RoundingMode.HALF_UP));
```

**Output**

```text
false
true
0.33
```

**Why this happens**

equals includes scale; compareTo tests numeric value. The division specifies its rounding policy because one-third has no finite exact decimal representation.


### 1.04 Collections lists sets queues and copies

**Concept and implementation choice**

Collection is an interface for groups of elements. Collections is a utility class with static operations. Map is part of the collections framework but does not extend Collection. List preserves positional order and permits duplicates; Set models uniqueness; Queue and Deque model processing order.

| Implementation | Ordering and typical cost | Trading use |
|---|---|---|
| ArrayList | Indexed get O(1), append amortised O(1), middle insert/remove O(n) | Trade snapshots and reports |
| LinkedList | Indexed access O(n); efficient end operations | Know its trade-offs; ArrayDeque often suits queues better |
| HashSet | Expected O(1) membership; no encounter-order guarantee | Execution-ID membership |
| LinkedHashSet | Expected O(1) membership; insertion order | Deduplication that retains first occurrence order |
| TreeSet | O(log n) operations; comparator-based uniqueness | Sorted distinct values with an agreed comparator |
| HashMap | Expected O(1) key lookup/update; no order guarantee | Trade lookup by immutable ID |
| LinkedHashMap | Defined insertion order or optional access order | Deterministic output or a small access-order cache |
| TreeMap | O(log n) get/put/remove; sorted keys | Ordered price levels |
| ArrayDeque | Amortised O(1) operations at either end; rejects null | FIFO event buffering or a stack |
| PriorityQueue | Offer/poll O(log n), peek O(1); iteration is not sorted | Track a small top-N set |
| EnumMap | Keys belong to one enum type | Counts by execution status |
| ConcurrentHashMap | Concurrent keyed access; no null keys/values | Concurrent counters or quote caches |
| CopyOnWriteArrayList | Snapshot traversal; updates copy the backing array | A small listener list with many reads and few writes |

Ordinary ArrayList, HashMap, TreeMap and HashSet are not thread-safe. Complexity statements assume the usual implementation and appropriate hashing; do not describe every HashMap operation as guaranteed O(1). A fail-fast iterator is a bug-detection aid, not a concurrency guarantee.

**Important methods**

| Method | Meaning or common trap |
|---|---|
| add(value), addAll(values) | Append/add elements when supported |
| contains(value) | Value membership; cost depends on implementation |
| remove(value) | Remove a matching value when supported |
| removeIf(predicate) | Remove all matching elements when supported |
| size(), isEmpty(), clear() | Basic inspection and mutation |
| iterator(), iterator.remove() | Controlled traversal and supported removal |
| get(index), set(index,value) | List positional access and replacement |
| remove(index) | List overload removes by index |
| sort(comparator), replaceAll(operator) | List sorting or transformation in place |
| subList(from,to) | Backed list view, not an independent copy |
| retainAll(values), removeAll(values) | Intersection-style retention or removal |
| toArray(String[]::new) | Produce a typed array |
| List.of(), Set.of(), copyOf() | Unmodifiable factories; understand null and uniqueness rules |

For List<Integer>, remove(1) removes index 1; remove(Integer.valueOf(1)) removes the value 1. Avoid structural modification through the collection during an enhanced for-loop. Use an appropriate iterator or removeIf() when removal is intended.

**Utilities factories and views**

Collections.sort(), reverse(), frequency(), disjoint(), min() and max() operate on collections under their respective preconditions. Collections.binarySearch() requires a list already sorted with the same ordering. Collections.unmodifiableList(backing) is a read-only view that still reflects backing-list changes. List.copyOf(backing) gives an unmodifiable snapshot of the list structure. Both may still contain references to mutable objects, although copyOf rejects null elements.

Arrays.asList() is fixed-size and backed by its array. List.of() is unmodifiable. Set.of() rejects duplicate elements and nulls; Map.of() rejects duplicate keys and null keys/values. Arrays.asList(new int[]{1,2}) makes a one-element List<int[]> rather than a list of boxed integers. Use Arrays.stream(numbers).boxed() to box primitive int elements.

**Scenario Keep unique IDs in encounter order**

A report should display each execution ID once in the order first seen.

**Input**

```text
IDs: [E2, E1, E2]
```

**Java**

```java
List<String> input = List.of("E2", "E1", "E2");
List<String> unique = new ArrayList<>(new LinkedHashSet<>(input));
System.out.println(unique);
System.out.println(unique.contains("E1"));
```

**Output**

```text
[E2, E1]
true
```

**Why this happens**

LinkedHashSet combines uniqueness with insertion order. ArrayList provides the required list result.

**Scenario Distinguish removing an index from a value**

A list of integer quantities has two remove overloads.

**Input**

```text
Quantities: [10, 20, 10]
```

**Java**

```java
List<Integer> quantities = new ArrayList<>(List.of(10, 20, 10));
quantities.remove(1);
System.out.println(quantities);
quantities.remove(Integer.valueOf(10));
System.out.println(quantities);
```

**Output**

```text
[10, 10]
[10]
```

**Why this happens**

remove(1) removes index 1. Wrapping the argument as Integer selects removal of the matching value.

**Scenario Understand a fixed-size list**

A test fixture created with Arrays.asList permits replacement but not a size change.

**Input**

```text
IDs: [T1, T2]
Replace index 0 with T0; then try to append T3
```

**Java**

```java
List<String> ids = Arrays.asList("T1", "T2");
ids.set(0, "T0");
System.out.println(ids);
try { ids.add("T3"); }
catch (UnsupportedOperationException error) { System.out.println("Fixed size"); }
```

**Output**

```text
[T0, T2]
Fixed size
```

**Why this happens**

Arrays.asList is backed by an array and has fixed size. Use a new ArrayList when the result must grow.

**Scenario Process events in FIFO order**

A small event buffer should return the oldest queued event first.

**Input**

```text
Events offered: E1, then E2
```

**Java**

```java
Deque<String> events = new ArrayDeque<>();
events.offerLast("E1");
events.offerLast("E2");
System.out.println(events.pollFirst());
System.out.println(events.peekFirst());
```

**Output**

```text
E1
E2
```

**Why this happens**

pollFirst removes the head, while peekFirst reads the next head without removing it.


### 1.05 Maps sorted maps and comparators

**Concept**

A Map associates one value with each key. Choose the key from stable business identity, such as trade ID. HashMap supports efficient keyed access, LinkedHashMap gives a defined encounter order, and TreeMap sorts keys. A concurrent map has different atomicity guarantees from an ordinary map.

**Important methods**

| Method | Trading example or behaviour |
|---|---|
| put(key,value), get(key) | Store or retrieve an order by ID |
| containsKey(key) | Distinguish absence from a stored null where null is allowed |
| getOrDefault(key,defaultValue) | Read a fallback; it does not insert |
| putIfAbsent(key,value) | Initialise only when absent or mapped to null |
| computeIfAbsent(key,function) | Create a per-symbol bucket or value when missing |
| merge(key,value,function) | Initialise or combine a non-null value |
| compute(key,function) | Recompute from the current mapping; null result removes it |
| replace(key,value), replace(key,old,new) | Replace an existing mapping, optionally conditionally |
| remove(key), remove(key,value) | Remove a mapping, optionally conditionally |
| keySet(), values(), entrySet() | Backed views of keys, values or entries |
| forEach(action), replaceAll(function) | Visit or update entries |

The short scenarios below use ordinary HashMap in a single thread. Atomicity guarantees depend on the implementation. ConcurrentHashMap supplies atomic keyed updates, but a mutable ArrayList stored as a map value does not become thread-safe merely because the map is concurrent. Keep compute functions short, avoid remote calls inside them, and do not recursively modify the same map from their remapping functions.

**Sorted price levels and comparator contracts**

NavigableMap methods firstEntry(), lastEntry(), floorEntry(), ceilingEntry(), lowerEntry() and higherEntry() locate boundary or neighbouring prices. With ascending price keys, the highest bid is lastEntry() and the lowest ask is firstEntry(). Empty maps return null for firstEntry()/lastEntry(). Prefer integral ticks or a clearly defined price-key representation.

TreeMap and TreeSet decide key equality using their comparator or natural comparison. BigDecimal("10.0") and BigDecimal("10.00") compare numerically equal, so a TreeSet groups them at one position even though equals() is false. HashSet uses equals()/hashCode() and treats those representations as distinct. Understand this contract difference before choosing decimal map keys.

Comparator.comparing(), comparingLong(), thenComparing(), reversed() and nullsLast() are useful. Reverse the price comparator before adding an ascending trade-ID tie-breaker; reversing the complete combined comparator reverses both criteria. Use Integer.compare/Long.compare instead of subtraction, which may overflow.

**Scenario Accumulate quantity using getOrDefault**

Two AAPL trades contribute quantities to the same symbol total.

**Input**

```text
Existing total: no AAPL entry
Incoming quantities: 100, then 200
```

**Java**

```java
Map<String, Integer> totals = new HashMap<>();
totals.put("AAPL", totals.getOrDefault("AAPL", 0) + 100);
totals.put("AAPL", totals.getOrDefault("AAPL", 0) + 200);
System.out.println(totals.get("AAPL"));
System.out.println(totals.getOrDefault("MSFT", 0));
System.out.println(totals.containsKey("MSFT"));
```

**Output**

```text
300
0
false
```

**Why this happens**

getOrDefault only reads a value or a fallback. put stores the updated total; the MSFT fallback does not create an entry.

**Scenario Use merge and computeIfAbsent**

Count AAPL executions and collect their IDs into a symbol bucket.

**Input**

```text
Executions: E1 and E2 for AAPL
```

**Java**

```java
Map<String, Integer> counts = new HashMap<>();
counts.merge("AAPL", 1, Integer::sum);
counts.merge("AAPL", 1, Integer::sum);
Map<String, List<String>> ids = new HashMap<>();
ids.computeIfAbsent("AAPL", symbol -> new ArrayList<>()).add("E1");
ids.computeIfAbsent("AAPL", symbol -> new ArrayList<>()).add("E2");
System.out.println(counts.get("AAPL"));
System.out.println(ids.get("AAPL"));
```

**Output**

```text
2
[E1, E2]
```

**Why this happens**

merge inserts or combines a value. computeIfAbsent creates a list only when needed and then returns the current list.

**Scenario Find the best bid and a neighbouring price**

An ascending TreeMap stores bid levels in integral price ticks.

**Input**

```text
Bids: 10000 -> 10, 10025 -> 20
Neighbour query: floor of 10010
```

**Java**

```java
NavigableMap<Long, Long> bids = new TreeMap<>();
bids.put(10000L, 10L);
bids.put(10025L, 20L);
System.out.println(bids.lastEntry().getKey());
System.out.println(bids.floorEntry(10010L).getKey());
```

**Output**

```text
10025
10000
```

**Why this happens**

The highest bid is the last entry. floorEntry returns the greatest key no higher than the requested price.


### 1.06 Streams pipelines filtering mapping and ordering

**Concept**

A Stream describes a processing pipeline over a source; it does not store elements like a collection. A typical trading pipeline selects eligible records, transforms them to notionals and collects or reduces the result. Prefer a readable loop when a pipeline obscures ordering, error handling or mutable state.

| Interface | Shape | Example |
|---|---|---|
| Predicate<T> | T to boolean | trade -> trade.status() == EXECUTED |
| Function<T,R> | T to R | Trade::symbol |
| Consumer<T> | T to no returned value | A controlled output action |
| Supplier<T> | No argument to T | ArrayList::new |
| BinaryOperator<T> | Two T values to T | BigDecimal::add |

A method reference is shorthand for a compatible lambda. Trade::symbol corresponds to trade -> trade.symbol(). A lambda's captured local variables must be final or effectively final; mutating an object referenced by such a variable may still be possible and may still be unsafe.

**Intermediate methods**

| Operation | Purpose | Trading example |
|---|---|---|
| filter(predicate) | Keep matching elements | Executed BUY trades |
| map(function) | Transform one element to one value | Trade to notional |
| flatMap(function) | Flatten each nested stream | Batches of executions to one execution stream |
| distinct() | Deduplicate by element equality | Exact duplicate objects under their equality contract |
| sorted(comparator) | Order elements | Notional descending with an ID tie-break |
| limit(n), skip(n) | Restrict or skip encounter positions | A small report page after ordering |
| peek(action) | Observe a pipeline during debugging | Do not put required audit writes here |
| mapToInt(), mapToLong(), mapToDouble() | Primitive streams | Integral quantities or counts |

Intermediate operations are lazy. Some operations, including sorted(), need buffering. distinct() uses the element's equals/hashCode semantics, so it does not deduplicate records by one chosen field automatically.

**Terminal methods**

| Operation | Result or behaviour |
|---|---|
| collect(collector) | A collection or grouped result |
| reduce(identity, accumulator) | Combine into a value such as BigDecimal total |
| toList() | Unmodifiable List, available since Java 16 |
| count() | long number of elements |
| min(comparator), max(comparator) | Optional element |
| findFirst(), findAny() | Optional element under their ordering semantics |
| anyMatch(), allMatch(), noneMatch() | Short-circuiting boolean queries |
| forEach(), forEachOrdered() | Terminal actions with different order guarantees |

A stream is consumed once; create a new stream for another traversal. findAny() need not return the first encounter element, particularly in parallel. On an empty stream, anyMatch() is false while allMatch() and noneMatch() are true. Do not use Optional.get() without establishing presence. Use orElse(), orElseGet() or orElseThrow() according to the contract; orElseGet() produces its fallback lazily.

**Reduction and parallel execution contracts**

An identity must be neutral for the operation, such as zero for addition. A reduction operation must be associative for correct regrouping, and its functions must obey the stream contracts. Exact BigDecimal addition without intermediate rounding is suitable for summation; introducing rounding at every addition can make regrouping change results. Floating-point summation can also vary with grouping.

parallelStream() does not guarantee faster execution. Consider data size, CPU work, splitting cost, ordering, shared resources and blocking. Avoid shared ArrayList.add() or a mutable external total inside parallel forEach(). Built-in collectors manage their own accumulation and combination rather than requiring you to mutate one shared result container. forEachOrdered() preserves encounter order for actions but does not make arbitrary shared state generally thread-safe.

Do not depend on peek() or another intermediate operation for required logging, persistence or audit events: an implementation can omit some operations when it can derive the terminal result without them. Required effects should be designed explicitly outside such optimisation-sensitive stages.

**Scenario Select executed trade IDs**

A report includes only executed trades and displays their IDs.

**Input**

```text
T1 EXECUTED, T2 PENDING, T3 EXECUTED
```

**Java**

```java
record Trade(String id, String status) {}
List<Trade> trades = List.of(new Trade("T1", "EXECUTED"),
    new Trade("T2", "PENDING"), new Trade("T3", "EXECUTED"));
List<String> ids = trades.stream()
    .filter(t -> t.status().equals("EXECUTED"))
    .map(Trade::id).toList();
System.out.println(ids);
```

**Output**

```text
[T1, T3]
```

**Why this happens**

filter selects matching records. map transforms each remaining record to its ID. toList triggers processing and returns an unmodifiable result.

**Scenario Flatten execution batches**

Two received batches should become one ordered stream of execution IDs.

**Input**

```text
Batches: [[E1, E2], [E3]]
```

**Java**

```java
List<List<String>> batches = List.of(List.of("E1", "E2"), List.of("E3"));
List<String> ids = batches.stream().flatMap(List::stream).toList();
System.out.println(ids);
```

**Output**

```text
[E1, E2, E3]
```

**Why this happens**

flatMap converts each inner list into a stream and joins those streams into one sequence.

**Scenario Show the top two prices**

A report displays the largest two prices, represented here as integral ticks.

**Input**

```text
Prices: [10050, 10025, 10075]
Limit: 2
```

**Java**

```java
List<Long> prices = List.of(10050L, 10025L, 10075L);
System.out.println(prices.stream().sorted(Comparator.reverseOrder()).limit(2).toList());
```

**Output**

```text
[10075, 10050]
```

**Why this happens**

sorted arranges descending values before limit selects the report size. A stable tie-breaker is needed when sorting domain objects with equal primary values.


### 1.07 Collectors grouping and financial reductions

**Concept**

A collector describes how to build an aggregate result. A classifier chooses a group; a downstream collector decides what to compute within that group. Use decimal reduction for money rather than converting monetary values to double.

**Important collectors**

| Collector | Typical use |
|---|---|
| toList(), toSet(), toCollection(ArrayList::new) | Collect elements; request a specific implementation when needed |
| toMap(key,value,merge) | Index trades with an explicit duplicate-key rule |
| groupingBy(classifier) | Group executions by symbol |
| mapping(mapper,downstream) | Transform grouped elements |
| reducing(identity,mapper,operator) | Aggregate BigDecimal values per group |
| counting(), summingLong() | Counts or integral quantity totals |
| partitioningBy(predicate) | Both boolean groups, such as accepted versus rejected |
| joining(delimiter) | Diagnostic ID text |
| collectingAndThen(downstream,finisher) | Apply a final conversion |
| maxBy(comparator), minBy(comparator) | Optional extrema per group |

Collectors.toList() does not specify a concrete list implementation or mutability guarantee. Stream.toList() is unmodifiable. Use toCollection(ArrayList::new) when a mutable ArrayList is explicitly required. toMap() without a merge function fails on duplicate keys; choose whether duplicates are errors, first-wins, latest-wins or combined values. A plain groupingBy result has no general insertion-order guarantee; supply an appropriate map factory when order matters.

For symbol grouping, the classifier chooses the symbol bucket. The mapper computes each trade's notional. The downstream reduction adds those values starting at zero. BigDecimal is appropriate for exact decimal money calculations; averagingDouble() is not a substitute for a specified decimal VWAP calculation.

**Scenario Count executions per symbol**

A dashboard counts how many execution records belong to each symbol.

**Input**

```text
Symbols: [AAPL, MSFT, AAPL]
```

**Java**

```java
List<String> symbols = List.of("AAPL", "MSFT", "AAPL");
Map<String, Long> counts = symbols.stream().collect(Collectors.groupingBy(
    symbol -> symbol, TreeMap::new, Collectors.counting()));
System.out.println(counts);
```

**Output**

```text
{AAPL=2, MSFT=1}
```

**Why this happens**

groupingBy creates a bucket per symbol and counting totals its elements. The TreeMap factory makes the printed key order deterministic.

**Scenario Define a duplicate-key policy**

Two execution records must be counted rather than failing on the same symbol key.

**Input**

```text
Symbols: [AAPL, AAPL]
```

**Java**

```java
Map<String, Integer> counts = Stream.of("AAPL", "AAPL").collect(
    Collectors.toMap(symbol -> symbol, symbol -> 1, Integer::sum));
System.out.println(counts);
```

**Output**

```text
{AAPL=2}
```

**Why this happens**

The third toMap argument combines duplicate keys. Omitting it would throw IllegalStateException for this input.

**Scenario Reduce decimal notionals**

Two already-calculated notionals must be summed exactly.

**Input**

```text
Notionals: 1002.50 and 510.00
```

**Java**

```java
BigDecimal total = Stream.of(new BigDecimal("1002.50"), new BigDecimal("510.00"))
    .reduce(BigDecimal.ZERO, BigDecimal::add);
System.out.println(total.toPlainString());
```

**Output**

```text
1512.50
```

**Why this happens**

Zero is the identity for addition. The reduction returns zero for an empty stream and preserves decimal precision without intermediate rounding.


### 1.08 Threads executors futures and lifecycle management

**Concept**

Concurrency means tasks can make progress during overlapping periods. Parallelism means work actually executes simultaneously. A trading test runner may use concurrency for independent checks, but correctness still depends on data ownership, atomic updates, visibility and ordering.

| Concept | Meaning | Example |
|---|---|---|
| Race condition | Correctness depends on an uncontrolled interleaving | Two workers lose a read-modify-write counter increment |
| Atomicity | An operation behaves indivisibly at its specified scope | AtomicLong.incrementAndGet() |
| Visibility | One thread can reliably observe another's published writes | Proper volatile, lock or future-completion coordination |
| Ordering | Defined relationships constrain observation of actions | Task effects are visible after successful Future.get() |
| Mutual exclusion | One thread enters a protected critical section at a time | One lock protects a multi-field invariant |
| Deadlock | Threads wait in a cycle for resources held by one another | Workers acquire two account locks in opposite orders |
| Starvation | A task repeatedly fails to obtain needed execution/resources | A poorly controlled or saturated executor |
| Backpressure | Producers are slowed or rejected when capacity is reached | A bounded execution-event queue |

volatile gives visibility/ordering guarantees for accesses to that field; it does not make count++ atomic. synchronized supplies monitor-based mutual exclusion and visibility when all participants use the same locking protocol. Atomic operations apply at their documented scope, not automatically across several unrelated fields or map keys. A cross-account transfer or consistent multi-symbol snapshot needs an appropriate wider protocol.

**Methods and lifecycle**

Runnable returns no result and cannot declare checked exceptions in run(). Callable<T> returns T and may throw checked exceptions. Calling Thread.start() schedules a new thread; calling run() directly is an ordinary method call on the caller's thread. A Thread instance can be started once.

| Method or API | Interview point |
|---|---|
| Thread.start(), join() | Start execution; wait for a thread to finish |
| Thread.sleep(...) | Pauses current thread; does not release owned monitors |
| interrupt(), isInterrupted() | Request interruption; inspect its flag |
| Thread.interrupted() | Checks and clears the current thread's flag |
| ExecutorService.submit(...) | Schedule a task and obtain a Future |
| execute(Runnable) | Schedule without returning a Future |
| Future.get() / get(timeout,unit) | Obtain result or observe failure/timeout |
| Future.cancel(true) | Request cancellation and possible interruption |
| invokeAll(tasks,timeout,unit) | Wait for a batch under a shared timeout and cancel unfinished tasks |
| shutdown() | Reject new tasks and allow submitted work to finish |
| shutdownNow() | Attempt interruption and return waiting tasks that never started |
| awaitTermination(timeout,unit) | Wait for termination; does not itself start shutdown |

Thread states are NEW, RUNNABLE, BLOCKED, WAITING, TIMED_WAITING and TERMINATED. A runnable thread is not guaranteed to be currently using a CPU. Cancellation is cooperative; a task ignoring interruption may continue. A timed Future.get() does not automatically cancel the task. A submitted task's failure is typically observed as ExecutionException from get(); do not discard futures and assume every task succeeded.

If InterruptedException is propagated, let the caller handle it. If it is caught without propagation, restore interruption with Thread.currentThread().interrupt() and normally stop the affected work. Avoid swallowing interruption or turning a cancellation into a successful trading result.

**Deadlines and cleanup**

Choose a pool size from the work and resource limits rather than one thread per trade. newFixedThreadPool() limits active workers but uses an unbounded work queue; a production producer may need a bounded ThreadPoolExecutor and an explicit rejection policy. For one overall deadline, track the remaining budget with System.nanoTime() or use a suitable timed batch API. Giving each future its own full timeout multiplies the total potential wait.

The runnable examples target Java 17 and therefore manage executor shutdown explicitly. ExecutorService became AutoCloseable after Java 17; do not assume Java 21 try-with-resources examples compile on Java 17. Virtual threads are a Java 21 topic: they can help workloads that spend time blocked, but do not make shared state safe or increase CPU capacity for compute-bound work.

**Monitor coordination**

Own an object's monitor before calling wait(), notify() or notifyAll(). A guarded wait uses while(conditionNotMet) wait(), because wakeups can be spurious and another thread may change the condition before the waiter reacquires the lock. wait() releases that object's monitor while waiting; sleep() does not. Prefer higher-level constructs when they match the problem. In tests, coordinate workers with a latch and await futures; do not use arbitrary sleeps as proof of completion.

**Scenario Obtain a simulated risk result**

Run one independent calculation on an executor and wait for its result.

**Input**

```text
Risk result produced by the task: 150.25
```

**Java**

```java
ExecutorService pool = Executors.newSingleThreadExecutor();
try {
    Future<BigDecimal> result = pool.submit(() -> new BigDecimal("150.25"));
    System.out.println(result.get(5, TimeUnit.SECONDS));
} finally {
    pool.shutdownNow();
}
```

**Output**

```text
150.25
```

**Why this happens**

submit returns a Future. get retrieves its value and observes failures. The executor is shut down by its owner in finally.

**Scenario Observe a worker failure**

A task rejects an invalid risk input; the caller must not silently ignore that failure.

**Input**

```text
Task throws IllegalArgumentException with message Risk input invalid
```

**Java**

```java
ExecutorService pool = Executors.newSingleThreadExecutor();
try {
    Future<Integer> result = pool.submit(() -> {
        throw new IllegalArgumentException("Risk input invalid");
    });
    try { result.get(5, TimeUnit.SECONDS); }
    catch (ExecutionException error) { System.out.println(error.getCause().getMessage()); }
} finally {
    pool.shutdownNow();
}
```

**Output**

```text
Risk input invalid
```

**Why this happens**

The task exception is captured by its Future and reported through ExecutionException. Reading the cause identifies the actual task failure.


### 1.09 Atomic updates concurrent maps and bounded queues

**Concept**

A thread-safe individual operation does not make a sequence of separate operations atomic. Use the API that protects the complete operation you need. A counter update, a per-symbol quote replacement and a multi-account transfer have different atomicity scopes.

**Important methods**

| API | Use and limitation |
|---|---|
| AtomicLong.get(), set() | Atomic value access under their memory semantics |
| incrementAndGet(), getAndIncrement(), addAndGet() | Atomic single-counter updates with different return values |
| compareAndSet(expected,newValue) | Conditional atomic update |
| updateAndGet(function) | Atomic recomputation; function may be retried, so avoid side effects |
| LongAdder.increment(), add(), sum() | Contended metrics; sum is not an atomic concurrent snapshot |
| ConcurrentHashMap.merge() | Atomic combination for one key |
| ConcurrentHashMap.compute() | Atomic per-key decision, such as retaining the greatest quote sequence |
| BlockingQueue.put(), take() | Blocking producer/consumer transfer |
| BlockingQueue.offer(), poll() and timed forms | Capacity-aware insertion and retrieval |
| CountDownLatch.await(), countDown() | Coordinate a one-shot start or completion condition |
| Semaphore.acquire(), release() | Bound access to a scarce resource |
| ReentrantLock.lock(), unlock() | Explicit lock; unlock in finally |

A ConcurrentHashMap does not support null keys or values. Its safe individual operations do not make get()/add/put() atomic. Its iteration is weakly consistent rather than a guaranteed single-instant snapshot. An ArrayList stored inside it remains an ordinary mutable ArrayList. LongAdder is useful for high-contention statistics, while a sequence generator generally needs a different contract such as AtomicLong.

ConcurrentHashMap.merge performs a keyed atomic increment. By contrast, counts.put(symbol, counts.getOrDefault(symbol,0L)+1) consists of separate reads and writes that can lose increments.

**Scenario Count work from two workers**

Two workers must increment one counter without losing updates.

**Input**

```text
Workers: 2
Increments per worker: 1000
```

**Java**

```java
AtomicLong count = new AtomicLong();
ExecutorService pool = Executors.newFixedThreadPool(2);
try {
    Runnable work = () -> { for (int i = 0; i < 1000; i++) count.incrementAndGet(); };
    Future<?> first = pool.submit(work);
    Future<?> second = pool.submit(work);
    first.get(5, TimeUnit.SECONDS);
    second.get(5, TimeUnit.SECONDS);
    System.out.println(count.get());
} finally {
    pool.shutdownNow();
}
```

**Output**

```text
2000
```

**Why this happens**

incrementAndGet is atomic. Waiting for both futures establishes completion before the final total is checked.

**Scenario Update a shared symbol count atomically**

Two completed updates contribute to the AAPL counter.

**Input**

```text
Initial map: empty
Updates: AAPL +1, AAPL +1
```

**Java**

```java
ConcurrentHashMap<String, Long> counts = new ConcurrentHashMap<>();
counts.merge("AAPL", 1L, Long::sum);
counts.merge("AAPL", 1L, Long::sum);
System.out.println(counts.get("AAPL"));
```

**Output**

```text
2
```

**Why this happens**

Each merge combines the current value atomically for that key. The operation remains safe when callers execute these merges concurrently.

**Scenario Apply backpressure at a queue boundary**

An event queue can hold only two records.

**Input**

```text
Capacity: 2
Offers: E1, E2, E3
```

**Java**

```java
BlockingQueue<String> queue = new ArrayBlockingQueue<>(2);
System.out.println(queue.offer("E1"));
System.out.println(queue.offer("E2"));
System.out.println(queue.offer("E3"));
System.out.println(queue.poll());
```

**Output**

```text
true
true
false
E1
```

**Why this happens**

offer reports failure when the bounded queue is full. The caller must choose whether to retry, reject or otherwise handle overload.


### 1.10 ThreadLocal context and CompletableFuture composition

**Concept and context cleanup**

ThreadLocal.get(), set(), remove() and withInitial() manage a value per thread. A worker pool reuses threads, so clean per-test context in finally to prevent state leaking into the next task. Storing the same mutable object in every thread's ThreadLocal does not make that object isolated or thread-safe. An explicitly passed test context may be clearer when work crosses thread boundaries.

**ThreadLocal methods**

| Method | Meaning |
|---|---|
| get() | Read the current thread's value |
| set(value) | Set the current thread's value |
| remove() | Remove the current thread's stored value |
| withInitial(supplier) | Supply an initial value separately for each thread |

**CompletableFuture methods**

supplyAsync() starts result-producing work, thenApply() maps a result, thenCompose() chains an asynchronous result, and thenCombine() combines independent results. allOf() completes when all supplied futures complete but does not directly return their values. exceptionally() handles failure and handle() sees success or failure. join() wraps exceptional completion in unchecked CompletionException; get() uses checked exceptions including ExecutionException and InterruptedException. For blocking checks, consider an explicit appropriate executor instead of assuming the common pool suits the workload. orTimeout() times out the future's completion; it does not guarantee termination of the underlying work.

**Scenario Remove task-specific context**

An order ID should not remain attached to a reused worker after its task finishes.

**Input**

```text
Context set for this task: ORDER-O1
```

**Java**

```java
ThreadLocal<String> context = new ThreadLocal<>();
try {
    context.set("ORDER-O1");
    System.out.println(context.get());
} finally {
    context.remove();
}
System.out.println(context.get());
```

**Output**

```text
ORDER-O1
null
```

**Why this happens**

The second read sees no stored context. In a pool, this cleanup prevents the next task on that worker from inheriting stale state.

**Scenario Combine two completed risk values**

Compose two simulated completed results without manually reading and adding them separately.

**Input**

```text
Credit result: 100.25
Market result: 50.00
```

**Java**

```java
CompletableFuture<BigDecimal> credit = CompletableFuture.completedFuture(new BigDecimal("100.25"));
CompletableFuture<BigDecimal> market = CompletableFuture.completedFuture(new BigDecimal("50.00"));
BigDecimal total = credit.thenCombine(market, BigDecimal::add).join();
System.out.println(total);
```

**Output**

```text
150.25
```

**Why this happens**

thenCombine combines two results. These futures are already completed, so this example teaches composition; it does not itself start parallel work.


## Part 2 Coding questions and answers


Each question is followed immediately by its available answer, explanation and related notes. Try the question first, then read the material directly beneath it. Exercises without an existing worked solution have an explicit answer-status note. The short scenarios in Part 1 can be used for revision.

For the final nine trading question-bank exercises, use this model unless the question supplies a different one:

```java
enum Side { BUY, SELL }
enum Status { PENDING, EXECUTED, CANCELLED, REJECTED }
record Trade(String tradeId, String symbol, Side side, Status status,
             BigDecimal price, long quantity) {}
```

Assume valid non-null fields, positive prices and quantities and one currency unless a question states otherwise. Earlier foundational exercises use their stated model and input contract. These are preparation questions, not verified prompts for the specific SMBC director interview.



### 2.01 Find duplicate trade IDs in second occurrence order

**Question**

Implement findDuplicateTradeIds(List<String>). Return each duplicated ID once, ordered by when its second occurrence is encountered. IDs are case-sensitive and matched exactly. Do not modify the input. Reject a null list, null ID or blank ID with IllegalArgumentException.

Example: [T1, T2, T2, T3, T1, T2] returns [T2, T1].

**Answer**

```java
import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static List<String> findDuplicateTradeIds(List<String> tradeIds) {
        if (tradeIds == null) {
            throw new IllegalArgumentException("Trade ID list must not be null");
        }
        Map<String, Integer> counts = new HashMap<>();
        List<String> duplicates = new ArrayList<>();
        for (String id : tradeIds) {
            if (id == null || id.isBlank()) {
                throw new IllegalArgumentException("Trade ID must not be null or blank");
            }
            int count = counts.getOrDefault(id, 0) + 1;
            counts.put(id, count);
            if (count == 2) {
                duplicates.add(id);
            }
        }
        return duplicates;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        List<String> input = Arrays.asList("T1", "T2", "T2", "T3", "T1", "T2");
        List<String> before = new ArrayList<>(input);
        check(findDuplicateTradeIds(input).equals(List.of("T2", "T1")), "Second occurrence ordering");
        check(input.equals(before), "Input remains unchanged");
        check(findDuplicateTradeIds(List.of()).isEmpty(), "Empty input");
        check(findDuplicateTradeIds(List.of("T1", "T2")).isEmpty(), "Unique IDs");
        check(findDuplicateTradeIds(List.of("T1", "T1", "T1")).equals(List.of("T1")), "Output once");
        check(findDuplicateTradeIds(List.of("T1", "t1", "t1", "T1")).equals(List.of("t1", "T1")), "Case sensitivity");
        rejects(() -> findDuplicateTradeIds(null));
        rejects(() -> findDuplicateTradeIds(Arrays.asList("T1", null)));
        rejects(() -> findDuplicateTradeIds(List.of("")));
        rejects(() -> findDuplicateTradeIds(List.of(" ")));
        System.out.println(findDuplicateTradeIds(input));
        System.out.println("PASS: " + checks + " checks");
    }
}
```

**Detailed explanation**

**Step 1 Validate before iterating**

Reject a null list before the enhanced for-loop. For every element, check null before isBlank so the method call is safe.

**Step 2 Choose separate state for counting and output**

The HashMap answers how often an ID has occurred. The ArrayList records when each duplicate becomes eligible for output. Those are different responsibilities.

**Step 3 Read update and store the count**

getOrDefault(id, 0) reads the current count or zero. Add one and store it using put; getOrDefault alone does not change the map.

**Step 4 Append exactly at the second occurrence**

count == 2 identifies the first time an ID becomes a duplicate. count > 1 would append it again at the third and later occurrences.

**Step 5 Return the list built during the scan**

Appending during the input scan preserves second-occurrence order. Iterating a HashMap of final counts would not preserve that order.

**Walkthrough with input and output**

| Input ID | Updated count | Result so far |
|---|---|---|
| T1 | 1 | [] |
| T2 | 1 | [] |
| T2 | 2 | [T2] |
| T3 | 1 | [T2] |
| T1 | 2 | [T2, T1] |
| T2 | 3 | [T2, T1] |

**Edge cases and tests**

An empty or all-unique input returns an empty list. Repeated copies of one ID appear once. Case and surrounding nonblank characters are matched exactly. The input list remains unchanged.

**Additional explanation and complexity**

The map stores a count for each ID. getOrDefault(id, 0) returns zero for a new ID. Add one, store the new count and append the ID only when the count reaches two. Third and later occurrences do not append another result. Appending during the input scan preserves the required ordering.

HashMap iteration order is not guaranteed. Counting everything and then filtering the map cannot recover second-occurrence order by itself. A LinkedHashMap of counts would preserve first insertion order, which is a different rule.

**Complexity:** Expected O(n) time and O(k) additional space for k distinct IDs.

**Corrections discussed**

- java.util.* does not import Collectors from the java.util.stream subpackage.
- A stream of map entries collects entries unless you map each entry to its key.
- An unused result-list variable should be removed or used.
- A frequency map can identify duplicates, but output ordering must be designed explicitly.

Source file: `programs/01-duplicate-trade-ids/Main.java`


### 2.02 Duplicate IDs using Streams

**Question**

Solve the same duplicate-ID problem with Streams while retaining second-occurrence order.

**Answer**

```java
import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static List<String> findDuplicateTradeIds(List<String> tradeIds) {
        if (tradeIds == null) {
            throw new IllegalArgumentException("List must not be null");
        }
        if (tradeIds.stream().anyMatch(id -> id == null || id.isBlank())) {
            throw new IllegalArgumentException("IDs must not be null or blank");
        }
        List<String> ids = new ArrayList<>(tradeIds);
        Map<String, List<Integer>> positions = IntStream.range(0, ids.size())
                .boxed()
                .collect(Collectors.groupingBy(ids::get));

        return positions.entrySet().stream()
                .filter(entry -> entry.getValue().size() > 1)
                .sorted(Comparator.comparingInt(entry -> entry.getValue().get(1)))
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        check(findDuplicateTradeIds(List.of("T1", "T2", "T2", "T3", "T1", "T2"))
                .equals(List.of("T2", "T1")), "Second occurrence order");
        check(findDuplicateTradeIds(List.of()).isEmpty(), "Empty input");
        check(findDuplicateTradeIds(new LinkedList<>(List.of("B", "A", "A", "B")))
                .equals(List.of("A", "B")), "LinkedList input");
        check(findDuplicateTradeIds(List.of("A", "A", "A")).equals(List.of("A")), "One output per ID");
        rejects(() -> findDuplicateTradeIds(null));
        rejects(() -> findDuplicateTradeIds(Arrays.asList("T1", null)));
        rejects(() -> findDuplicateTradeIds(List.of(" ")));
        System.out.println("PASS: " + checks + " checks");
    }
}
```

**Detailed explanation**

**Step 1 Validate the input**

Reject null or blank IDs before grouping. The preliminary anyMatch stops as soon as invalid data is found.

**Step 2 Copy for predictable indexed access**

The ArrayList copy makes ids.get(index) efficient even when the supplied list is a LinkedList.

**Step 3 Generate and group positions**

IntStream.range generates indexes from zero to size minus one. boxed turns primitive indexes into Integer objects. groupingBy(ids::get) uses the ID at each index as the group key.

**Step 4 Keep groups with a duplicate**

A positions list of size greater than one identifies a duplicated ID. The second position is get(1), because list indexes start at zero.

**Step 5 Sort before extracting IDs**

The comparator orders entries by the second position. map(Map.Entry::getKey) then changes a stream of map entries into a stream of Strings.

**Step 6 Collect the ordered result**

The terminal collector executes the pipeline and returns the list. This approach trades additional memory and sorting for a stream-based description.

**Walkthrough with input and output**

| ID | Encounter positions | Second position |
|---|---|---|
| T1 | [0, 4] | 4 |
| T2 | [1, 2, 5] | 2 |
| T3 | [3] | Not duplicated |

Sorting eligible entries by the second position produces [T2, T1].

**Edge cases and tests**

Empty input produces no groups. A repeated ID still produces one group. The example deliberately avoids a stateful external HashSet inside filter; the shorter shortcut is retained only as a caution in the original explanation.

**Additional explanation and complexity**

IntStream generates input indexes. groupingBy associates each ID with its ordered list of positions. Keep IDs with at least two positions, sort by position number two, then return the keys. For the main example, T1 has positions [0, 4], while T2 has [1, 2, 5]. T2's second position is earlier.

Copying the input to an ArrayList ensures efficient indexed access even if the caller supplied a LinkedList. Compared with the loop, this approach stores more information and sorts the duplicated IDs.

A shorter sequential shortcut was also discussed:

```java
Set<String> seen = new HashSet<>();
List<String> duplicates = tradeIds.stream()
        .filter(id -> !seen.add(id))
        .distinct()
        .collect(Collectors.toList());
```

This shortcut assumes valid input and sequential execution. Its predicate mutates external state, which Java's stream guidance discourages. Do not switch it to parallel execution. Prefer the loop or the index-based version when discussing clear, maintainable interview code.

**Complexity:** O(n + d log d) expected time for d duplicated IDs, and O(n) additional space.

Source file: `programs/02-duplicate-ids-streams/Main.java`


### 2.03 Validate a trading order and return all errors

**Question**

Implement validateOrder(symbol, quantity, price). Return every validation error in symbol, quantity, price order. Symbol must not be null or blank; quantity must be positive; price must be non-null and positive. Return an empty list for a valid order. Invalid values produce messages rather than exceptions.

**Answer**

```java
import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static List<String> validateOrder(String symbol, int quantity, BigDecimal price) {
        List<String> errors = new ArrayList<>();
        if (symbol == null || symbol.isBlank()) {
            errors.add("Symbol is required");
        }
        if (quantity <= 0) {
            errors.add("Quantity must be positive");
        }
        if (price == null || price.compareTo(BigDecimal.ZERO) <= 0) {
            errors.add("Price must be positive");
        }
        return errors;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        check(validateOrder("AAPL", 100, new BigDecimal("150.50")).isEmpty(), "Valid order");
        check(validateOrder("", 0, new BigDecimal("-10")).equals(List.of(
                "Symbol is required", "Quantity must be positive", "Price must be positive")), "All errors");
        check(validateOrder("AAPL", 10, null).equals(List.of("Price must be positive")), "Null price");
        check(validateOrder(null, -1, BigDecimal.ZERO).size() == 3, "All invalid boundaries");
        check(validateOrder(" ", 1, BigDecimal.ONE).equals(List.of("Symbol is required")), "Blank symbol");
        System.out.println("PASS: " + checks + " checks");
    }
}
```

**Detailed explanation**

**Step 1 Create a result list**

This method returns validation findings. It does not throw for ordinary invalid field values because the caller needs all errors together.

**Step 2 Check the symbol**

A null symbol and a blank symbol both add the same business message. Short-circuit OR protects the isBlank call.

**Step 3 Check quantity independently**

quantity <= 0 rejects both zero and negatives. This is a separate if, so an invalid symbol does not prevent a quantity error from being recorded.

**Step 4 Check the decimal price**

A null price is rejected before comparison. compareTo(BigDecimal.ZERO) <= 0 means the price is numerically zero or negative.

**Step 5 Return errors in rule order**

Messages are added in symbol, quantity, price order. A valid order adds nothing and therefore returns an empty list.

**Walkthrough with input and output**

| Field | Input | Decision |
|---|---|---|
| Symbol | empty string | Add Symbol is required |
| Quantity | 0 | Add Quantity must be positive |
| Price | -10 | Add Price must be positive |

All three messages are returned, in that order.

**Edge cases and tests**

Test each invalid field alone, all invalid fields together, null price, blank symbol and the exact zero boundaries. Using else-if or printing instead of adding messages would violate the output contract.

**Additional explanation and complexity**

Each independent if statement checks one field and appends a message. Using else-if would stop later checks when an earlier field is invalid. A null price must be checked before calling compareTo(). The OR expression short-circuits, so compareTo() is skipped when the value is null.

This validation function intentionally collects errors. A constructor in a later exercise intentionally throws an exception instead: the two contracts serve different purposes.

**Complexity:** O(1) field checks, plus the cost of examining the symbol text.

**Corrections discussed**

- this cannot be used in a static method. Parameters already contain the input values.
- Objects.requireNonNull() throws NullPointerException; it does not collect validation messages.
- BigDecimal cannot be compared with <=; use compareTo().
- List is an interface. Instantiate ArrayList, not new List<String>().
- System.out.println() prints a message; errors.add() includes it in the returned result.
- Java keywords are case-sensitive: if is valid; If is not.

Source file: `programs/03-order-validation/Main.java`


### 2.04 Calculate total trade quantity by symbol

**Question**

Given Trade objects containing symbol and quantity, return Map<String, Integer> with the total quantity for each symbol. Do not modify the input. Return an empty map for an empty list. Inputs are valid and totals fit in int.

**Answer**

```java
import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    static class Trade {
        final String symbol;
        final int quantity;
        Trade(String symbol, int quantity) {
            this.symbol = symbol;
            this.quantity = quantity;
        }
    }

    public static Map<String, Integer> totalQuantityBySymbol(List<Trade> trades) {
        Map<String, Integer> totals = new HashMap<>();
        for (Trade trade : trades) {
            totals.put(trade.symbol,
                    totals.getOrDefault(trade.symbol, 0) + trade.quantity);
        }
        return totals;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        List<Trade> trades = List.of(new Trade("AAPL", 100), new Trade("MSFT", 50),
                new Trade("AAPL", 200), new Trade("MSFT", 25), new Trade("GOOG", 10));
        check(totalQuantityBySymbol(trades).equals(Map.of("AAPL", 300, "MSFT", 75, "GOOG", 10)), "Totals");
        check(totalQuantityBySymbol(List.of()).isEmpty(), "Empty input");
        check(totalQuantityBySymbol(List.of(new Trade("AAPL", 5))).get("AAPL") == 5, "Single trade");
        System.out.println(totalQuantityBySymbol(trades));
        System.out.println("PASS: " + checks + " checks");
    }
}
```

**Detailed explanation**

**Step 1 Initialise a fresh map**

The method name is not a map variable. totals is the local map that will store one running quantity per symbol.

**Step 2 Read one trade at a time**

The enhanced for-loop gives access to that trade’s symbol and quantity. No sorting or input modification is necessary.

**Step 3 Default a new symbol to zero**

getOrDefault(symbol, 0) means the same update works for a first trade and for subsequent trades.

**Step 4 Add the current quantity**

Add trade.quantity to the current accumulated number, then put the updated number under the same symbol.

**Step 5 Return the map**

The output has one total for every observed symbol. HashMap output order is unspecified and is not part of this exercise’s contract.

**Walkthrough with input and output**

| Trade | Previous total | New total |
|---|---|---|
| AAPL 100 | 0 | AAPL 100 |
| MSFT 50 | 0 | MSFT 50 |
| AAPL 200 | 100 | AAPL 300 |
| MSFT 25 | 50 | MSFT 75 |

**Edge cases and tests**

Empty input returns an empty map. Repeated symbols must add rather than replace their quantities. The original exercise assumes totals fit in int; discuss long, exact overflow checks or another representation if that guarantee changes.

**Additional explanation and complexity**

The map has one entry per symbol. Get the current quantity, default to zero when the symbol is new, add the trade's quantity and put the updated value back into the map.

```java
int currentTotal = totals.getOrDefault(trade.symbol, 0);
int updatedTotal = currentTotal + trade.quantity;
totals.put(trade.symbol, updatedTotal);
```

For AAPL quantities 100 and 200, the updates are 0 + 100 = 100, then 100 + 200 = 300. getOrDefault() itself does not change the map; put() stores the result. If a key explicitly maps to null, getOrDefault() returns null rather than the default; this counting implementation never stores null values.

A follow-up asked for a merge() rewrite. It was posed as an exercise in the chat rather than worked through there.

**Complexity:** Expected O(n) time and O(k) space for k symbols.

**Corrections discussed**

- The method name totalQuantityBySymbol is not a map variable. Declare a result map such as totals.
- Map.get(symbol) returns the quantity, not a symbol string. Comparing that Integer to trade.symbol is incorrect.
- No contains check is required when getOrDefault() handles new symbols.

Source file: `programs/04-total-quantity/Main.java`


### 2.05 Find the trade with the highest quantity

**Question**

Return the Trade object with the highest quantity. Preserve the first encountered object on a tie. Return null for an empty list. Do not sort or modify the input. The list and its elements are non-null.

**Answer**

```java
import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    static class Trade {
        final String symbol;
        final int quantity;
        Trade(String symbol, int quantity) {
            this.symbol = symbol;
            this.quantity = quantity;
        }
    }

    public static Trade findLargestTrade(List<Trade> trades) {
        Trade largest = null;
        for (Trade trade : trades) {
            if (largest == null || trade.quantity > largest.quantity) {
                largest = trade;
            }
        }
        return largest;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        Trade firstWinner = new Trade("MSFT", 250);
        Trade laterTie = new Trade("AMZN", 250);
        List<Trade> trades = List.of(new Trade("AAPL", 100), firstWinner,
                new Trade("GOOG", 150), laterTie);
        check(findLargestTrade(trades) == firstWinner, "First object wins tie");
        check(findLargestTrade(List.of()) == null, "Empty list");
        check(findLargestTrade(List.of(laterTie)) == laterTie, "Single object");
        check(findLargestTrade(List.of(new Trade("A", -10), new Trade("B", -5))).quantity == -5,
                "Algorithm does not assume a zero starting maximum");
        System.out.println(findLargestTrade(trades).symbol);
        System.out.println("PASS: " + checks + " checks");
    }
}
```

**Detailed explanation**

**Step 1 Represent no winner with null**

Before seeing a trade there is no winning object. Starting with null also avoids assuming quantities are greater than an arbitrary starting number.

**Step 2 Accept the first trade**

largest == null is true on the first iteration, so the first object becomes the current winner.

**Step 3 Compare later quantities**

Replace the winner only when the new quantity is strictly greater. Using >= would incorrectly keep the last tied trade.

**Step 4 Keep the object reference**

Storing the Trade itself preserves its symbol and associated data. It also lets the caller verify that the first original object won the tie.

**Step 5 Handle an empty input naturally**

No loop iteration runs for an empty list, so the method returns null as required.

**Walkthrough with input and output**

| Symbol | Quantity | Current winner after comparison |
|---|---|---|
| AAPL | 100 | AAPL 100 |
| MSFT | 250 | MSFT 250 |
| GOOG | 150 | MSFT 250 |
| AMZN | 250 | MSFT 250 |

**Edge cases and tests**

Test empty input, one object, a larger value at the end and tied maximum quantities. The algorithm changes only its local winning reference; it does not sort or change the list.

**Additional explanation and complexity**

largest begins as null because no trade has been examined. The first trade becomes the current winner. A later object replaces it only when its quantity is strictly greater. Using > instead of >= preserves the first object on equal quantities. Returning the object retains its associated symbol and other fields.

**Complexity:** O(n) time and O(1) additional space.

Source file: `programs/05-largest-trade/Main.java`


### 2.06 Find trades missing from actual results

**Question**

Return IDs present in expected but absent from actual. Preserve expected-list order. Ignore extra IDs in actual. Do not modify either list. Both inputs contain unique, non-null IDs and are non-null.

Example: expected [T1, T2, T3, T4], actual [T2, T4, T5] returns [T1, T3].

**Answer**

```java
import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static List<String> findMissingTrades(List<String> expected, List<String> actual) {
        Set<String> actualTrades = new HashSet<>(actual);
        List<String> missingTrades = new ArrayList<>();
        for (String trade : expected) {
            if (!actualTrades.contains(trade)) {
                missingTrades.add(trade);
            }
        }
        return missingTrades;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        List<String> expected = Arrays.asList("T1", "T2", "T3", "T4");
        List<String> actual = Arrays.asList("T2", "T4", "T5");
        check(findMissingTrades(expected, actual).equals(List.of("T1", "T3")), "Missing IDs");
        check(expected.equals(List.of("T1", "T2", "T3", "T4")), "Expected unchanged");
        check(actual.equals(List.of("T2", "T4", "T5")), "Actual unchanged");
        check(findMissingTrades(List.of("T1", "T2"), List.of("T2", "T1")).isEmpty(), "All present");
        check(findMissingTrades(List.of("T1", "T2"), List.of()).equals(List.of("T1", "T2")), "Actual empty");
        check(findMissingTrades(List.of(), List.of("T1")).isEmpty(), "Expected empty");
        System.out.println("PASS: " + checks + " checks");
    }
}
```

**Detailed explanation**

**Step 1 Index actual IDs for membership**

new HashSet<>(actual) copies the actual IDs into a set. Membership has expected constant-time cost under ordinary hashing assumptions.

**Step 2 Scan expected rather than actual**

The question asks what expected data is missing. Iterating actual instead would find unexpected extras, which is the opposite direction.

**Step 3 Append only absent IDs**

The negated contains check is true only when the actual set has no matching ID.

**Step 4 Preserve encounter order**

The result is appended in expected-list order. HashSet iteration order is irrelevant because the method never uses it to construct the result.

**Step 5 Return a new list**

The original expected and actual lists are preserved. This also works when those lists are fixed-size or unmodifiable.

**Walkthrough with input and output**

| Expected ID | In actual [T2, T4, T5] | Action |
|---|---|---|
| T1 | No | Append T1 |
| T2 | Yes | Skip |
| T3 | No | Append T3 |
| T4 | Yes | Skip |

The result is [T1, T3]. Extra actual ID T5 is ignored.

**Edge cases and tests**

If actual is empty, every expected ID is returned. If expected is empty, the result is empty. The original inputs contain unique non-null IDs; define a duplicate policy if that changes.

**Additional explanation and complexity**

Create a set from actual so each membership lookup has expected constant time. Scan expected, adding only IDs that the set does not contain. The scan order preserves expected order.

```java
Set<String> actualTrades = new HashSet<>(actual);
```

Set<String> is the variable's interface type. HashSet is its implementation. The constructor copies the input elements into the new set and removes duplicate values without modifying the original list. This is equivalent to creating an empty HashSet and calling addAll(actual).

**Complexity:** Expected O(n + m) time; O(m) set storage plus the output list.

**Corrections discussed**

- Looping through actual and checking absence from expected answers the reverse question.
- Add missing IDs to a new result list, not to expected.
- Arrays.asList() returns a fixed-size list. add() and remove() are unsupported, although replacing an existing element with set() is supported.
- Returning expected would return the original expected records rather than just the missing ones.

Source file: `programs/06-missing-trades/Main.java`


### 2.07 Check a palindrome after cleaning the string

**Question**

Return whether a string reads the same forwards and backwards, ignoring letter case and ordinary spaces. Return false for null and true for the empty string. Inputs contain English letters and ordinary spaces.

**Answer**

```java
import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static boolean isPalindrome(String text) {
        if (text == null) return false;
        String cleaned = text.replace(" ", "").toLowerCase(Locale.ROOT);
        int left = 0;
        int right = cleaned.length() - 1;
        while (left < right) {
            if (cleaned.charAt(left) != cleaned.charAt(right)) return false;
            left++;
            right--;
        }
        return true;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        String[] inputs = {"madam", "Race car", "Never odd or even", "Java", "", null, "   ", "a", "ab"};
        boolean[] expected = {true, true, true, false, true, false, true, true, false};
        for (int i = 0; i < inputs.length; i++) {
            check(isPalindrome(inputs[i]) == expected[i], "Palindrome input: " + inputs[i]);
        }
        System.out.println("PASS: " + checks + " checks");
    }
}
```

**Detailed explanation**

**Step 1 Apply the null contract first**

Return false before invoking any String methods when text is null.

**Step 2 Normalise only what the question permits**

Remove ordinary spaces and convert English letters to lower case with Locale.ROOT. Punctuation removal and full Unicode case folding are outside this exercise.

**Step 3 Place indexes at opposite ends**

left starts at zero and right at length minus one. charAt retrieves the character at the current position.

**Step 4 Stop at the first mismatch**

If a pair differs, the complete string cannot be a palindrome, so return false immediately.

**Step 5 Move inward after a match**

Increment left and decrement right. When they meet or cross, every required pair matched and the result is true.

**Walkthrough with input and output**

| Cleaned text | Compared positions | Characters |
|---|---|---|
| racecar | 0 and 6 | r and r |
| racecar | 1 and 5 | a and a |
| racecar | 2 and 4 | c and c |

The middle e needs no partner. Result: true.

**Edge cases and tests**

The empty string and a space-only string normalise to empty and return true. A one-character string returns true. Java is rejected at the first unequal outside pair. The cleaned copy accounts for the additional O(n) space.

**Additional explanation and complexity**

Remove ordinary spaces and convert letters to lower case. Compare the first and last characters, then move both indexes inward. Return false at the first mismatch. When all pairs match, return true. An empty cleaned string skips the loop.

charAt(index) retrieves a character. This exercise intentionally does not define full Unicode case folding or punctuation removal.

**Complexity:** O(n) time and O(n) additional space for the cleaned string.

Source file: `programs/07-palindrome-cleaned/Main.java`


### 2.08 Check a palindrome with constant extra space

**Question**

Improve the palindrome implementation so it does not allocate a cleaned copy of the string. Preserve the same English-letter and ordinary-space contract.

**Answer**

```java
import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static boolean isPalindrome(String text) {
        if (text == null) return false;
        int left = 0;
        int right = text.length() - 1;
        while (left < right) {
            char first = text.charAt(left);
            char last = text.charAt(right);
            if (first == ' ') {
                left++;
                continue;
            }
            if (last == ' ') {
                right--;
                continue;
            }
            if (Character.toLowerCase(first) != Character.toLowerCase(last)) return false;
            left++;
            right--;
        }
        return true;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        String[] inputs = {"madam", "Race car", "Never odd or even", "Java", "", null, "   ", " a ", " a b "};
        boolean[] expected = {true, true, true, false, true, false, true, true, false};
        for (int i = 0; i < inputs.length; i++) {
            check(isPalindrome(inputs[i]) == expected[i], "Palindrome input: " + inputs[i]);
        }
        System.out.println("PASS: " + checks + " checks");
    }
}
```

**Detailed explanation**

**Step 1 Keep the original string**

Use indexes into the input instead of creating a normalised copy.

**Step 2 Skip a left-side space**

Advance left and continue to the next iteration. The characters are read again at the new indexes rather than using stale cached values.

**Step 3 Skip a right-side space**

Decrement right and continue. These steps preserve the ordinary-space rule without allocating a second string.

**Step 4 Compare normalised characters**

Character.toLowerCase normalises each compared English letter. A mismatch returns false.

**Step 5 Advance both indexes on a match**

Every iteration moves at least one index, so the scan always makes progress and remains linear.

**Walkthrough with input and output**

| Input Race car | Decision |
|---|---|
| R versus r | Match after case conversion |
| a versus a | Match |
| c versus c | Match |
| e versus space | Skip the right-side space |
| Indexes meet at e | Return true |

**Edge cases and tests**

Null returns false. Empty, one-letter and space-only inputs return true. O(1) space refers to extra working storage: the original input still exists. This change improves memory use rather than the optimal O(n) worst-case time.

**Additional explanation and complexity**

The two indexes still move inward, but spaces are skipped directly in the original string. Character.toLowerCase() normalises each letter only when it is compared. continue starts the next loop iteration immediately. No cleaned copy is allocated.

The worst-case running time remains linear. A complete positive palindrome check needs to examine characters across the string.

**Complexity:** O(n) time and O(1) additional space.

Source file: `programs/08-palindrome-constant-space/Main.java`


### 2.09 Create an immutable Order with validation and notional

**Question**

Implement an immutable Order with orderId, symbol, int quantity and BigDecimal price. Initialise fields through the constructor. Reject null or blank identifiers, non-positive quantity and null or non-positive price using IllegalArgumentException. Provide getters and getNotional().

**Answer**

```java
import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    static final class Order {
        private final String orderId;
        private final String symbol;
        private final int quantity;
        private final BigDecimal price;

        public Order(String orderId, String symbol, int quantity, BigDecimal price) {
            if (orderId == null || orderId.isBlank()) {
                throw new IllegalArgumentException("Order ID is required");
            }
            if (symbol == null || symbol.isBlank()) {
                throw new IllegalArgumentException("Symbol is required");
            }
            if (quantity <= 0) {
                throw new IllegalArgumentException("Quantity must be positive");
            }
            if (price == null || price.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException("Price must be positive");
            }
            this.orderId = orderId;
            this.symbol = symbol;
            this.quantity = quantity;
            this.price = price;
        }
        public String getOrderId() { return orderId; }
        public String getSymbol() { return symbol; }
        public int getQuantity() { return quantity; }
        public BigDecimal getPrice() { return price; }
        public BigDecimal getNotional() {
            return price.multiply(BigDecimal.valueOf(quantity));
        }
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        Order order = new Order("O1", "AAPL", 10, new BigDecimal("100.25"));
        check(order.getOrderId().equals("O1"), "ID getter");
        check(order.getSymbol().equals("AAPL"), "Symbol getter");
        check(order.getQuantity() == 10, "Quantity getter");
        check(order.getPrice().compareTo(new BigDecimal("100.25")) == 0, "Price getter");
        check(order.getNotional().compareTo(new BigDecimal("1002.50")) == 0, "Notional");
        rejects(() -> new Order(null, "AAPL", 1, BigDecimal.ONE));
        rejects(() -> new Order(" ", "AAPL", 1, BigDecimal.ONE));
        rejects(() -> new Order("O1", " ", 1, BigDecimal.ONE));
        rejects(() -> new Order("O1", null, 1, BigDecimal.ONE));
        rejects(() -> new Order("O1", "AAPL", 0, BigDecimal.ONE));
        rejects(() -> new Order("O1", "AAPL", -1, BigDecimal.ONE));
        rejects(() -> new Order("O1", "AAPL", 1, null));
        rejects(() -> new Order("O1", "AAPL", 1, BigDecimal.ZERO));
        rejects(() -> new Order("O1", "AAPL", 1, new BigDecimal("-1")));
        System.out.println(order.getNotional());
        System.out.println("PASS: " + checks + " checks");
    }
}
```

**Detailed explanation**

**Step 1 Validate identifiers before assignments**

Null or blank orderId and symbol values produce IllegalArgumentException before the object can be successfully constructed.

**Step 2 Enforce quantity and price rules**

The exercise requires positive quantity and positive non-null price. The price null check short-circuits before compareTo.

**Step 3 Assign final fields once**

this.field = parameter stores each validated value. Private final fields, a final class and no setters prevent the mutation paths relevant to this model.

**Step 4 Check the types of stored values**

String and BigDecimal are immutable and quantity is a primitive. These getters therefore do not leak mutable internal objects; a future List field would need additional care.

**Step 5 Calculate and return notional**

Convert quantity using BigDecimal.valueOf, multiply it by price and return the arithmetic result. The * operator cannot multiply a BigDecimal.

**Walkthrough with input and output**

| Construction or call | Result |
|---|---|
| O1, AAPL, 10, 100.25 | Construction succeeds |
| getNotional() | 100.25 times 10 becomes 1002.50 |
| O1, AAPL, 0, 100.25 | IllegalArgumentException |
| O1, AAPL, 10, null | IllegalArgumentException before compareTo |

**Edge cases and tests**

Test each constructor guard independently and verify that a valid object exposes the expected values. The rule rejecting non-positive prices belongs to this exercise; real instrument rules must decide whether negative prices are valid.

**Additional explanation and complexity**

The constructor validates values before assigning them. this.orderId means the field on the new object; orderId means the constructor parameter. Each call to new Order(...) creates an object with its own field values.

private prevents callers from directly accessing fields. final fields cannot be reassigned after initialisation. The final class prevents subclassing; no setters are provided. String and BigDecimal are themselves immutable, so these getters do not expose mutable internal objects. If the class later stores lists or dates, defensive copying may also be required.

BigDecimal.valueOf(quantity) converts the integral quantity into a decimal object. multiply() performs decimal multiplication and the method returns its result.

The positive-price rule is the contract of this exercise. Real instrument rules should define whether zero or negative prices are permitted rather than assuming one validation policy applies to every trading product.

**Complexity:** A constant number of fields is processed; decimal arithmetic cost depends on operand size.

**Corrections discussed**

- quantity * price does not compile because BigDecimal does not support the multiplication operator.
- A method declared to return BigDecimal must return a value on its normal path.
- Constructor validation throws here because an invalid Order must not be successfully constructed. The earlier validation exercise instead collected all messages for a caller.
- Use quantity < 0 when rejecting only negative quantities; use quantity <= 0 when zero is invalid too.

Source file: `programs/09-immutable-order/Main.java`


### 2.10 Deduplicate orders using equals and hashCode

**Question**

Two Order objects represent the same order when their orderId values match, even if other fields differ. Override equals() and hashCode(), then remove duplicate orders while preserving the first encountered object and its position. Assume valid non-null inputs and IDs.

**Answer**

```java
import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    static final class Order {
        private final String orderId;
        private final String symbol;
        private final int quantity;
        private final BigDecimal price;
        public Order(String orderId, String symbol, int quantity, BigDecimal price) {
            this.orderId = orderId;
            this.symbol = symbol;
            this.quantity = quantity;
            this.price = price;
        }
        public String getOrderId() { return orderId; }
        public int getQuantity() { return quantity; }
        @Override
        public boolean equals(Object other) {
            if (this == other) return true;
            if (!(other instanceof Order)) return false;
            Order otherOrder = (Order) other;
            return Objects.equals(this.orderId, otherOrder.orderId);
        }
        @Override
        public int hashCode() {
            return Objects.hash(orderId);
        }
    }

    public static List<Order> removeDuplicates(List<Order> orders) {
        Set<Order> uniqueOrders = new LinkedHashSet<>(orders);
        return new ArrayList<>(uniqueOrders);
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        Order first = new Order("O1", "AAPL", 10, new BigDecimal("100.25"));
        Order second = new Order("O2", "MSFT", 20, new BigDecimal("50.00"));
        Order duplicate = new Order("O1", "AAPL", 99, new BigDecimal("101.00"));
        List<Order> result = removeDuplicates(List.of(first, second, duplicate));
        check(first.equals(duplicate), "ID-based equality");
        check(duplicate.equals(first), "Symmetry");
        check(first.equals(first), "Reflexivity");
        check(!first.equals(null), "Null comparison");
        check(!first.equals("O1"), "Different type");
        check(!first.equals(second), "Different ID");
        check(first.hashCode() == duplicate.hashCode(), "Equal values have equal hashes");
        check(result.size() == 2 && result.get(0) == first && result.get(1) == second,
                "Preserve first objects and their order");
        check(removeDuplicates(List.of()).isEmpty(), "Empty input");
        for (Order order : result) System.out.println(order.getOrderId() + " -> quantity " + order.getQuantity());
        System.out.println("PASS: " + checks + " checks");
    }
}
```

**Detailed explanation**

**Step 1 Define business identity explicitly**

This exercise treats matching orderId values as the same order even if quantities or prices differ. That is a chosen rule, not a universal definition for every order system.

**Step 2 Handle identity and type safely**

this == other returns true for the same object. instanceof rejects incompatible types and null before the cast.

**Step 3 Compare the identity field**

Objects.equals compares the two String IDs by value. The other fields are intentionally outside the chosen identity rule.

**Step 4 Hash the same identity field**

Objects.hash(orderId) gives equal orders equal hash codes. Hash collisions between different IDs are permitted; equality still decides whether an entry is a duplicate.

**Step 5 Use an insertion-ordered set**

LinkedHashSet suppresses equal later objects while retaining the original first object and encounter order. Converting it to ArrayList supplies the requested result type.

**Walkthrough with input and output**

| Object encountered | ID already present | Kept object |
|---|---|---|
| O1 quantity 10 | No | First O1 |
| O2 quantity 20 | No | O2 |
| O1 quantity 99 | Yes | Original O1 quantity 10 remains |

**Edge cases and tests**

Check reflexive equality, equal-ID symmetry, comparison with null and another type, equal hashes for equal IDs, empty input and preservation of the first actual object. Keeping the ID immutable avoids changing its hash behaviour while stored.

**Additional explanation and complexity**

this == other checks reference identity. instanceof rejects objects of other types and also returns false for null. The cast lets the method access Order fields. Objects.equals() compares the two IDs by value.

Hash-based collections use hash codes to locate candidate entries and equals() to determine equality. Equal objects must have equal hash codes; equal hash codes do not necessarily mean the objects are equal. Hash collisions are permitted.

LinkedHashSet removes equal objects while preserving insertion order. Constructing an ArrayList from the set returns the required list. The first O1 object remains, including its original quantity of 10.

super.equals() and super.hashCode() appeared in the starter as temporary object-identity behaviour. They must be replaced to implement the business identity rule.

**Complexity:** Expected O(n) time and O(k) space for k unique order IDs.

Source file: `programs/10-order-equality/Main.java`


### 2.11 Parse an HTML blotter and calculate executed BUY notional

**Question**

Extract rows from a table with ID blotter, map them to Trade objects and calculate price times quantity for EXECUTED BUY orders. The sample contains four trades. T1 contributes 100.25 × 10 = 1002.50; T4 contributes 25.50 × 20 = 510.00. The SELL trade T2 and PENDING trade T3 are excluded. The expected total is 1512.50.

The sample is a single-currency snapshot. HTML retrieval, JavaScript rendering, pagination and real HTTP calls are separate responsibilities.

This earlier HTML exercise is retained for completeness; it requires jsoup.

**Answer**

```java
import java.math.BigDecimal;
import java.util.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main {

    enum Side { BUY, SELL }
    enum Status { EXECUTED, PENDING, CANCELLED, REJECTED }

    // A record is a compact data holder. Access fields with trade.price(), etc.
    record Trade(String id, String symbol, Side side, Status status,
                 BigDecimal price, BigDecimal quantity) {}

    public static List<Trade> parseTrades(String html) {
        if (html == null || html.isBlank()) {
            throw new IllegalArgumentException("HTML must not be null or blank");
        }

        Document document = Jsoup.parse(html);
        Element table = document.selectFirst("table#blotter");
        if (table == null) {
            throw new IllegalArgumentException("Blotter table is missing");
        }

        Elements rows = table.select("tbody > tr");
        List<Trade> trades = new ArrayList<>();

        for (Element row : rows) {
            Elements cells = row.select("td");
            if (cells.size() != 6) {
                throw new IllegalArgumentException("Each trade row must have six cells");
            }

            String id = cells.get(0).text().trim();
            String symbol = cells.get(1).text().trim();
            Side side = Side.valueOf(
                    cells.get(2).text().trim().toUpperCase(Locale.ROOT));
            Status status = Status.valueOf(
                    cells.get(3).text().trim().toUpperCase(Locale.ROOT));
            BigDecimal price = new BigDecimal(cells.get(4).text().trim());
            BigDecimal quantity = new BigDecimal(cells.get(5).text().trim());

            if (id.isBlank() || symbol.isBlank()) {
                throw new IllegalArgumentException("Trade ID and symbol are required");
            }

            Trade trade = new Trade(id, symbol, side, status, price, quantity);
            trades.add(trade);
        }

        return trades;
    }

    public static BigDecimal totalExecutedBuyNotional(List<Trade> trades) {
        return trades.stream()
                .filter(trade -> trade.side() == Side.BUY
                        && trade.status() == Status.EXECUTED)
                .map(trade -> trade.price().multiply(trade.quantity()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private static int passed;
    private static int totalChecks;

    private static void check(String description, boolean condition) {
        totalChecks++;
        if (condition) passed++;
        System.out.println((condition ? "PASS: " : "FAIL: ") + description);
    }

    public static void main(String[] args) {
        // Scope: one currency, fixed column order, no commas or currency symbols.
        // This fixture represents a rendered UI snapshot, not a live page.
        String html = """
            <table id="blotter">
              <thead><tr>
                <th>Trade ID</th><th>Symbol</th><th>Side</th>
                <th>Status</th><th>Price</th><th>Quantity</th>
              </tr></thead>
              <tbody>
                <tr><td>T1</td><td>AAPL</td><td>BUY</td><td>EXECUTED</td><td>100.25</td><td>10</td></tr>
                <tr><td>T2</td><td>MSFT</td><td>SELL</td><td>EXECUTED</td><td>50.00</td><td>20</td></tr>
                <tr><td>T3</td><td>GOOG</td><td>BUY</td><td>PENDING</td><td>12.00</td><td>5</td></tr>
                <tr><td>T4</td><td>AMZN</td><td>BUY</td><td>EXECUTED</td><td>25.50</td><td>20</td></tr>
              </tbody>
            </table>
            """;

        List<Trade> parsed = parseTrades(html);
        check("Parser extracts all four trades", parsed.size() == 4);
        check("First trade fields are mapped correctly", !parsed.isEmpty()
                && parsed.get(0).id().equals("T1")
                && parsed.get(0).symbol().equals("AAPL")
                && parsed.get(0).side() == Side.BUY
                && parsed.get(0).status() == Status.EXECUTED
                && parsed.get(0).price().compareTo(new BigDecimal("100.25")) == 0
                && parsed.get(0).quantity().compareTo(new BigDecimal("10")) == 0);

        BigDecimal actual = totalExecutedBuyNotional(parsed);
        BigDecimal expected = new BigDecimal("1512.50");
        check("UI total is 1512.50", actual.compareTo(expected) == 0);

        // Independent calculator checks let you practise TODO 2 before TODO 1.
        Trade buy = new Trade("B1", "AAPL", Side.BUY, Status.EXECUTED,
                new BigDecimal("0.10"), new BigDecimal("3"));
        Trade sell = new Trade("S1", "MSFT", Side.SELL, Status.EXECUTED,
                new BigDecimal("99"), new BigDecimal("10"));
        Trade pending = new Trade("P1", "GOOG", Side.BUY, Status.PENDING,
                new BigDecimal("99"), new BigDecimal("10"));

        check("Calculator includes an executed BUY exactly",
                totalExecutedBuyNotional(List.of(buy)).compareTo(new BigDecimal("0.30")) == 0);
        check("Calculator excludes SELL and PENDING orders",
                totalExecutedBuyNotional(List.of(buy, sell, pending))
                        .compareTo(new BigDecimal("0.30")) == 0);
        check("No matching trades returns zero",
                totalExecutedBuyNotional(List.of(sell, pending)).compareTo(BigDecimal.ZERO) == 0);
        check("Empty trade list returns zero",
                totalExecutedBuyNotional(List.of()).compareTo(BigDecimal.ZERO) == 0);
        check("Empty table returns no trades",
                parseTrades("<table id='blotter'><tbody></tbody></table>").isEmpty());

        System.out.println("Expected UI total: " + expected.toPlainString());
        System.out.println("Actual UI total:   " + actual.toPlainString());
        System.out.println("Checks passed: " + passed + "/" + totalChecks);
    }
}
```

**Detailed explanation**

**Step 1 Parse the supplied snapshot**

Jsoup builds a document from the HTML string. The parser checks that the required table exists before selecting rows.

**Step 2 Select body rows and validate width**

tbody > tr excludes the header row. The six-cell check runs before indexed access so a missing field does not silently shift every subsequent value.

**Step 3 Extract and convert fields**

text().trim() gets cell content. Enum conversion normalises recognised labels, and BigDecimal parses the decimal strings directly.

**Step 4 Create one domain object per row**

Parsing returns all four rows, including SELL and PENDING orders. It does not discard data based on a calculation-specific rule.

**Step 5 Filter and calculate separately**

The calculator keeps EXECUTED BUY records, multiplies each price by quantity and reduces the notionals from zero. This separation lets another adapter supply the same domain objects later.

**Walkthrough with input and output**

| Trade | Parsed | Included in total | Contribution |
|---|---|---|---|
| T1 BUY EXECUTED | Yes | Yes | 1002.50 |
| T2 SELL EXECUTED | Yes | No | 0 |
| T3 BUY PENDING | Yes | No | 0 |
| T4 BUY EXECUTED | Yes | Yes | 510.00 |

Total: 1512.50.

**Edge cases and tests**

An empty supported table returns an empty trade list and zero total. Missing columns, invalid decimal text and unknown labels should not be silently ignored. This version assumes fixed column order, supported formatting and a complete same-currency snapshot; jsoup does not execute browser JavaScript.

**Additional explanation and complexity**

Jsoup.parse(html) creates a searchable document. selectFirst("table#blotter") locates the table. table.select("tbody > tr") identifies data rows. row.select("td") identifies cells. text().trim() extracts cell text. In the fixed-column practice version, indexes 0 through 5 mean ID, symbol, side, status, price and quantity.

Side.valueOf() and Status.valueOf() convert normalised strings into enums. Locale.ROOT makes case conversion independent of the machine's default locale. new BigDecimal(cellText) converts prices and quantities directly from their decimal representation. Each row produces a new Trade that is appended to the result list. The parser returns all trades; the calculator applies business filters.

The validation checks reject missing HTML, a missing table, an incorrect cell count and blank identifiers. Invalid numbers and unknown enum labels also throw exceptions. This simplified parser assumes the supplied column order and table structure.

filter() keeps executed buys. map() computes each notional. reduce(BigDecimal.ZERO, BigDecimal::add) adds the values and returns zero for no matches. BigDecimal quantity supports fractional quantities in this model.

Complexity: parsing depends on the HTML input size; the calculation is O(n) for n trades, apart from decimal operand costs. The parsed model uses O(n) space.

**Reusable parser variation**

The earlier full TradeBlotter implementation accepts a table selector and maps header names to column indexes. It tolerates reordered columns, rejects duplicate trade IDs, validates supported statuses and positive quantity, and adds row numbers to row parsing errors. Nested tables and merged cells are outside its contract. Numeric strings use a dot decimal separator without grouping commas or currency symbols. Signed prices are allowed in that full model; instrument rules should determine restrictions.

Its source, HTML fixture, 32-check runner and readme are in programs/12-html-blotter/. The complete OneCompiler program above is in programs/13-onecompiler-blotter-complete/Main.java. The original practice snapshots and Maven dependency configuration are in practice/onecompiler/.

**JSON comparison follow-up**

The sample summary JSON contains currency GBP and executedBuyNotional "1512.50". A JSON parser and live API reconciliation were proposed as the next exercise, but were not implemented in the previous chat. Compare totals numerically with compareTo() after agreeing currency, units, filters, rounding, pagination coverage and snapshot time. Matching totals alone do not establish that every individual trade matches.


### 2.12 Reusable HTML parser with header mapping

**Question**

Variation: build a reusable parser that accepts a table selector, locates columns by header name, maps rows to Trade objects and calculates executed BUY notional. Support reordered columns and report invalid rows clearly. Agree a duplicate-ID policy and a supported table/number-format contract.

**Answer**

This is the full reusable HTML parser originally supplied, including its domain model and Streams calculator. The complete runnable project and check runner are included in programs/12-html-blotter/.

```java
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.math.BigDecimal;
import java.util.*;

/** Java 17+. All rows must belong to the same currency and snapshot. */
public final class TradeBlotter {
    public enum Side { BUY, SELL }
    public enum Status { NEW, PENDING, PARTIALLY_FILLED, EXECUTED, CANCELLED, REJECTED }

    public record Trade(String id, String symbol, Side side, Status status,
                        BigDecimal price, BigDecimal quantity) {
        public Trade {
            if (id == null || id.isBlank() || symbol == null || symbol.isBlank()) {
                throw new IllegalArgumentException("Trade ID and symbol are required");
            }
            Objects.requireNonNull(side, "side");
            Objects.requireNonNull(status, "status");
            Objects.requireNonNull(price, "price");
            Objects.requireNonNull(quantity, "quantity");
            if (quantity.signum() <= 0) {
                throw new IllegalArgumentException("Quantity must be positive");
            }
        }

        public BigDecimal notional() {
            return price.multiply(quantity);
        }
    }

    public static final class HtmlTradeParser {
        private static final Set<String> REQUIRED = Set.of(
                "trade id", "symbol", "side", "status", "price", "quantity");

        public List<Trade> parse(String html, String tableSelector) {
            if (html == null || html.isBlank()) {
                throw new IllegalArgumentException("HTML is required");
            }
            if (tableSelector == null || tableSelector.isBlank()) {
                throw new IllegalArgumentException("Table selector is required");
            }

            Elements matches = Jsoup.parse(html).select(tableSelector);
            if (matches.size() != 1 || !matches.first().tagName().equals("table")) {
                throw new IllegalArgumentException("Selector must identify exactly one table");
            }
            Element table = matches.first();
            // This adapter deliberately supports simple tables, not nested or merged cells.
            if (!table.select("td table, th table, [colspan], [rowspan]").isEmpty()) {
                throw new IllegalArgumentException("Nested tables and merged cells are unsupported");
            }
            Elements headerRows = table.select("thead > tr");
            if (headerRows.size() != 1) {
                throw new IllegalArgumentException("Exactly one header row is required");
            }
            Elements headers = headerRows.first().children();
            Map<String, Integer> columns = new HashMap<>();
            for (int i = 0; i < headers.size(); i++) {
                String name = headers.get(i).text().strip().toLowerCase(Locale.ROOT);
                if (!headers.get(i).tagName().equals("th") || name.isBlank()
                        || columns.putIfAbsent(name, i) != null) {
                    throw new IllegalArgumentException("Invalid or duplicate table header: " + name);
                }
            }
            if (!columns.keySet().containsAll(REQUIRED)) {
                Set<String> missing = new TreeSet<>(REQUIRED);
                missing.removeAll(columns.keySet());
                throw new IllegalArgumentException("Missing headers: " + missing);
            }

            List<Trade> trades = new ArrayList<>();
            Set<String> ids = new HashSet<>();
            Elements rows = table.select("tbody > tr");
            for (int i = 0; i < rows.size(); i++) {
                try {
                    Elements cells = rows.get(i).children();
                    if (cells.size() != headers.size()
                            || cells.stream().anyMatch(cell -> !cell.tagName().equals("td"))) {
                        throw new IllegalArgumentException("Cell count or structure differs from header");
                    }
                    Trade trade = new Trade(
                            text(cells, columns, "trade id"),
                            text(cells, columns, "symbol"),
                            Side.valueOf(text(cells, columns, "side").toUpperCase(Locale.ROOT)),
                            Status.valueOf(text(cells, columns, "status").toUpperCase(Locale.ROOT)),
                            new BigDecimal(text(cells, columns, "price")),
                            new BigDecimal(text(cells, columns, "quantity")));
                    if (!ids.add(trade.id())) {
                        throw new IllegalArgumentException("Duplicate trade ID: " + trade.id());
                    }
                    trades.add(trade);
                } catch (IllegalArgumentException e) {
                    throw new IllegalArgumentException("Blotter row " + (i + 1) + ": " + e.getMessage(), e);
                }
            }
            return List.copyOf(trades);
        }

        private static String text(Elements cells, Map<String, Integer> columns, String field) {
            String value = cells.get(columns.get(field)).text().strip();
            if (value.isBlank()) {
                throw new IllegalArgumentException("Blank field: " + field);
            }
            return value;
        }
    }

    public static BigDecimal totalExecutedBuyNotional(List<Trade> trades) {
        return trades.stream()
                .filter(trade -> trade.side() == Side.BUY && trade.status() == Status.EXECUTED)
                .map(Trade::notional)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
```

**Detailed explanation**

**Step 1 Identify exactly one supported table**

The selector must find a table. Unsupported merged cells or nested tables are rejected so the parser cannot misinterpret their structure.

**Step 2 Build the header index**

Trim and normalise each header and map its name to its current index. Duplicate headers and missing required names fail before row parsing.

**Step 3 Validate and map every row**

Require the row width to match the headers, then look up each field by its header index rather than a fixed hard-coded position.

**Step 4 Apply validation and identity rules**

The domain constructor validates required data and positive quantity. A Set tracks IDs so duplicate trade rows cannot accidentally double the total.

**Step 5 Report context on failure**

The row loop wraps parsing failures with the one-based row number. Invalid records fail clearly rather than disappearing from a financial calculation.

**Step 6 Return the parsed model and aggregate separately**

List.copyOf returns an unmodifiable list structure. The independent calculator uses the same domain type and business filters as the simple parser.

**Walkthrough with input and output**

| Header | Original index | Example reordered index |
|---|---|---|
| Trade ID | 0 | 4 |
| Price | 4 | 5 |
| Quantity | 5 | 0 |

Header lookup changes the indexes, so the same trade values are extracted after the columns move.

**Edge cases and tests**

Test reordered columns, missing and duplicate headers, malformed row width, invalid enums/numbers, duplicate IDs and zero matching orders. The adapter intentionally rejects unsupported table shapes and locale-dependent number formats instead of guessing.

**Additional explanation and complexity**

The header map translates each required field name to its current column index. Every row is converted into a validated domain object. Duplicate IDs and malformed rows fail clearly. The calculation operates independently of extraction. Complexity is linear in the parsed input and processed cells, apart from decimal operand costs, with storage for the DOM, trades, headers and IDs. The runnable parser project includes the existing 32-check runner.


### 2.13 Quantity mismatches between maps

**Question**

Implement Set<String> findQuantityMismatches(Map<String, Integer> expected, Map<String, Integer> actual). Return expected IDs missing from actual or present with a different quantity. Ignore extra actual IDs. Use containsKey() and value equality, not Integer reference identity. Example: expected {T1=100, T2=200, T3=150}, actual {T1=100, T2=250, T4=300} returns {T2, T3}. Inputs and their keys/values are non-null.

**Answer status**

No worked answer for this exact question was supplied in the earlier chat.


### 2.14 Reconcile prices and quantities between UI and API objects

**Question**

Using record Trade(String id, BigDecimal price, BigDecimal quantity), implement Set<String> findDifferences(List<Trade> uiTrades, List<Trade> apiTrades). Return IDs appearing in only one list or whose prices or quantities differ numerically. Ignore decimal scale differences. With UI T1(100.00,10), T2(50.00,20), T4(25.00,5), and API T1(100.0,10.0), T2(50.00,25), T3(12.00,5), return {T2,T3,T4}. IDs are unique per source; all values are non-null and refer to the same currency and snapshot. A HashMap keyed by ID was suggested.

**Answer status**

No worked answer for this exact question was supplied in the earlier chat.


### 2.15 Find a cell when table columns move

**Question**

Implement String findCellValue(String html, String tradeId, String columnName). Locate table#blotter, map headers to indexes, locate the row by its Trade ID cell and return the requested cell's trimmed text. Headers are matched case-insensitively after trimming; IDs are exact. Throw IllegalArgumentException for a missing table, required column or trade. Assume one header row, unique headers/IDs and consistent row widths. A sample header order was Status, Price, Trade ID, Quantity. T1 had EXECUTED,100.25,T1,10 and T2 had PENDING,25.50,T2,20. Lookups for T2/Price, T1/Status and T2/Quantity should return 25.50, EXECUTED and 20. Reorder columns as the key test.

**Answer status**

No worked answer for this exact question was supplied in the earlier chat.


### 2.16 Calculate executed BUY notional by symbol

**Question**

Time: 20 minutes. Implement Map<String, BigDecimal> calculateBuyNotional(List<Trade> trades). Filter executed buys, compute price times quantity and sum per symbol. Return an empty map for empty input and preserve the input.

Example: AAPL BUY EXECUTED 100.25×10; AAPL BUY EXECUTED 102.00×5; AAPL SELL EXECUTED 105.00×20; MSFT BUY EXECUTED 50.00×20. Expected AAPL=1512.50, MSFT=1000.00. Follow-up: what goes wrong with toMap() when duplicate symbols have no merge policy?

**Answer status**

The original chat did not include a complete worked answer for this exact question. Related short method scenarios appear in Part 1.


### 2.17 Calculate volume weighted average execution price

**Question**

Time: 25 minutes. Implement Map<String, BigDecimal> calculateVwap(List<Trade> trades). Include all executed trades regardless of side. For each symbol, VWAP = sum(price×quantity) / sum(quantity). Return four decimal places using HALF_UP; omit symbols with no executed trades. AAPL executions 100×10 and 110×30 produce 107.5000. Follow-up: why is the unweighted average of the two prices wrong?

**Answer status**

The original chat did not include a complete worked answer for this exact question. Related short method scenarios appear in Part 1.


### 2.18 Find the largest executed trades

**Question**

Time: 20 minutes. Implement List<Trade> findLargestTrades(List<Trade> trades, int limit). Include executed trades, sort by notional descending and break equal-notional ties by trade ID ascending. Return at most limit results. Zero returns an empty list; negative limits are invalid. Follow-up: how would you find the top ten from millions of trades without sorting every record?

Streams are lazy until a terminal operation initiates processing. Behavioural parameters should generally be stateless and should not modify the stream source. Mutating shared lists from a parallel stream is not made safe by the stream itself.

**Answer status**

The original chat did not include a complete worked answer for this exact question. Related short method scenarios appear in Part 1.


### 2.19 Reconcile two complete trade snapshots

**Question**

Time: 30 minutes. Implement Set<String> findDifferences(List<Trade> expected, List<Trade> actual) using the shared model from the Streams questions. Return IDs present in only one list or whose symbol, side, status, price or quantity differs. Compare prices numerically. IDs are unique within each source. Target expected O(n+m) time. Follow-up: return a field-level mismatch report rather than just IDs.

**Answer status**

The original chat did not include a complete worked answer for this exact question. Related short method scenarios appear in Part 1.


### 2.20 Deduplicate execution events

**Question**

Time: 20 minutes. Use record Execution(String executionId, String orderId, long quantity). Implement List<Execution> removeDuplicateExecutions(List<Execution> events), retaining the first execution per executionId in encounter order. Events E1/O1/10, E2/O1/15 and E1/O1/10 produce E1/O1/10 and E2/O1/15. Different executions for one order are legitimate. Follow-up: what if the same execution ID arrives with conflicting quantities?

**Answer status**

The original chat did not include a complete worked answer for this exact question. Related short method scenarios appear in Part 1.


### 2.21 Maintain best bid and ask

**Question**

Time: 30 minutes. Build a single-threaded price-level order book with updateBid(long priceInTicks,long quantity), updateAsk(...), Optional<PriceLevel> bestBid() and bestAsk(). Updates replace quantity at a price; zero removes the level; negative quantity is invalid. Highest bid is best; lowest ask is best. Bids 10000→10 and 10025→20 yield best bid 10025. Asks 10050→15 and 10075→30 yield best ask 10050. Follow-up: choose a collection supporting ordered prices and efficient updates. TreeMap provides logarithmic get/put/remove operations.

Core collections topics also raised were HashMap versus LinkedHashMap ordering, Set uniqueness, equality and hashing contracts, mutable map keys, copying inputs and efficient membership checks.

**Answer status**

The original chat did not include a complete worked answer for this exact question. Related short method scenarios appear in Part 1.


### 2.22 Fix a concurrent trade counter

**Question**

Time: 25 minutes. Ten workers update a ConcurrentHashMap<String, Long> using the following code:

```java
counts.put(symbol, counts.getOrDefault(symbol, 0L) + 1);
```

Explain the race and implement void recordTrade(String symbol) and long getTradeCount(String symbol). Ten workers each recording 10,000 AAPL trades must produce 100,000 after all workers complete. Follow-up: thread-safe individual map operations do not make an arbitrary read-modify-write sequence atomic.

**Answer status**

The original chat did not include a complete worked answer for this exact question. Related short method scenarios appear in Part 1.


### 2.23 Prevent stale market data updates

**Question**

Time: 30 minutes. Define record Quote(String symbol, BigDecimal price, long sequence). Implement a thread-safe cache with update(Quote) and Optional<Quote> latest(String symbol). Accept only sequences greater than the stored sequence; equal or lower sequences leave the value unchanged. Concurrent AAPL sequences 12,10,13 must finish with sequence 13. Unrelated symbols should be able to update concurrently. Follow-up: why is get/compare/put unsafe, and how can atomic per-key compute() help?

**Answer status**

The original chat did not include a complete worked answer for this exact question. Related short method scenarios appear in Part 1.


### 2.24 Run trading risk checks concurrently

**Question**

Time: 35 minutes. Simulate credit, position and market-risk checks as Callable tasks. Run at most three at once under one overall one-second deadline. Report PASS, FAIL, ERROR or TIMEOUT for every check. Request cancellation of unfinished tasks, handle interruption and shut down the executor you own. Assume tasks cooperate with interruption. Follow-up: waiting one second for every future separately can exceed the overall deadline; cancellation requests do not guarantee immediate termination.

Additional discussion topics were ExecutorService, ThreadLocal isolation for parallel tests, shared mutable state, deterministic concurrency testing, proper cleanup and diagnosing memory retention in long-running test suites. These were preparation themes rather than fully worked answers in this chat.

**Answer status**

The original chat did not include a complete worked answer for this exact question. Related short method scenarios appear in Part 1.


## Part 3 Appendices

Use these for setup, troubleshooting, oral interview revision and source references.


### 3.01 Running the examples and using the study pack

This guide collects the Java exercises, worked answers, explanations, corrections and interview follow-ups from our preparation chat through 14 November 2026. Related messages are consolidated by topic so you can study each question together with its answer.

The worked-program sections contain complete runnable Java examples. Exercises that were introduced without a worked solution are preserved separately and labelled "Question only in the previous chat". No unanswered exercise is presented as a completed answer.

Use Java 17 or later. Each core example has its own Main.java in a separate folder. Paste one example at a time into OneCompiler's Main.java, then click Run. Do not paste several public Main classes into one source file. HTML parsing examples also require jsoup; all other core examples use only the Java standard library.

The pack includes a searchable offline HTML guide, this Markdown guide, source files and the original blotter fixtures. Open index.html after extracting the ZIP. The HTML guide has a text search box, navigation and copy buttons for code blocks; it makes no network requests.

To run the supplied checks locally on macOS or Linux, open a terminal in this directory and run `sh run-all.sh`. Source files are compiled independently into .build. The original blotter dependency is included in lib. Checks are educational examples, not a certification of a production trading system.

The "Trade" and "Order" models vary between exercises. Some use a long or int quantity; the HTML blotter uses BigDecimal quantity to support fractional values. Follow the model in the selected program rather than mixing declarations from different examples.


### 3.02 Compiler errors and collection pitfalls

**If versus if**

Java keywords are case-sensitive. An uppercase If may cause a misleading "; expected" message. Write if.

**Class and filename must match**

Save public class Main in Main.java, or public class Order in Order.java. Class names contain no spaces. If renaming a class, also update its constructor and all corresponding type references.

**Compile and run commands differ**

```text
javac FindDuplicateTrades.java
java FindDuplicateTrades
```

The compiler command needs the .java filename; the run command uses the class name. An error saying "Class names, 'FindDuplicateTrades', are only accepted if annotation processing is explicitly requested" commonly means a bare class name was passed to javac instead of a source filename. Enabling annotation processing is not the fix for that filename mistake.

**Missing Collectors import and wrong stream element type**

```java
import java.util.stream.Collectors;

List<String> ids = counts.entrySet().stream()
        .filter(entry -> entry.getValue() > 1)
        .map(Map.Entry::getKey)
        .collect(Collectors.toList());
```

Without map(Map.Entry::getKey), this stream produces a list of entries, not strings. Even with the mapping, an unordered HashMap does not satisfy the earlier second-occurrence ordering requirement.

**Interface versus implementation**

```java
List<String> result = new ArrayList<>();
Set<String> ids = new HashSet<>();
Map<String, Integer> counts = new HashMap<>();
```

List, Set and Map are interfaces; create a concrete implementation. Arrays.asList() is fixed-size. List.of() and Map.of() are unmodifiable and reject nulls. new ArrayList<>(input) makes a separate list structure; it is a shallow copy, not a deep copy of contained objects.

**Comparison types**

Use equals() for String content, == for enum constants and primitive comparisons, and compareTo() for numeric BigDecimal comparisons. Integer references compared with == may compare object identities; do not rely on integer caching for value comparison.

**OneCompiler dependency runs**

The HTML exercise needed Add Dependencies and a pom.xml containing jsoup 1.24.1. In that session, the top Run button used Maven, while the file-context Run action bypassed dependency setup. Maven compiled other Java files too, exposing an older class/filename mismatch. The supplied practice pom includes only Main.java so the blotter exercise can run independently. A public Main entry point was needed for that Maven setup.

Core Java exercises need no jsoup dependency. In a workspace retaining the restricted practice pom, use Main.java for the selected exercise or adjust the build configuration deliberately.


### 3.03 Oral interview questions and short answers

**Objects**

- "An immutable Order validates its inputs, prevents reassignment, exposes no mutation operations and does not leak mutable internal state."
- "Two equal objects must have equal hash codes. Equal hash codes alone do not establish equality."
- "A final reference cannot be reassigned, but the referenced object's contents may still be mutable."
- "Object is the root class; Objects is a null-safety and equality utility class."

References: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/Object.html and https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/Objects.html

**Collections**

- Why use entrySet() when both key and value are needed? It exposes each pair directly rather than requiring another lookup by key.
- Does HashMap preserve insertion order? No; choose LinkedHashMap when that is the requirement.
- Can a mutable order be used as a key? Only if changes cannot affect its equality/hash behaviour while stored; an immutable ID key is usually simpler.
- Why does Arrays.asList().add() fail? The returned list has fixed size.
- Is an unmodifiable collection deeply immutable? No; contained mutable objects may still change.

References: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/Collection.html and https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/Map.html

**Streams**

- map transforms each input; flatMap transforms and flattens nested results.
- collect builds a result container; reduce combines elements into a value under its algebraic contract.
- A parallel stream is a performance choice, not a thread-safety mechanism.
- Comparator.comparing(Trade::notional).reversed().thenComparing(Trade::tradeId) means descending notional and ascending ID; the model must define those accessors.

References: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/stream/Stream.html and https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/stream/Collectors.html

**Concurrency**

- A volatile counter can still lose increments because count++ is a compound operation.
- AtomicLong protects a single counter; it does not make an entire order-processing transaction atomic.
- shutdown() initiates orderly shutdown; awaitTermination() waits; shutdownNow() is an interruption attempt, not a forced kill.
- Consistent lock ordering helps prevent deadlock. Limit lock scope and avoid remote calls while holding a shared lock.
- Clean ThreadLocal values and release resources in finally or an appropriate resource-management construct.

References: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/package-summary.html and https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/ExecutorService.html

**Additional follow-ups**

- Rewrite duplicate detection using two sets instead of a frequency map.
- Rewrite totals.put(symbol, totals.getOrDefault(symbol,0) + quantity) using merge().
- Explain the difference between || and && in null-safe validation.
- Explain why discarded BigDecimal.add() results do not update a total.
- Confirm currency, filters, units and snapshot alignment before comparing UI and API totals.


### 3.04 Other prompts preparation plan and role context

**Other prompts mentioned**

The preparation discussion also mentioned maximum contiguous subarray sum (Kadane's algorithm), second-largest array values, moving zeros, reversing words, financial ratio services, asynchronous status polling, bounded execution, pipeline optimisation, memory leaks, heap versus stack, and Java keyword / HTTP / wait-strategy recall. These were topic suggestions; no worked Java program for those topics was supplied in the previous chat.

An earlier maximum-subarray prompt was: given an integer array, return the sum of its contiguous subarray with the largest sum. Follow-ups included explaining the brute-force approach and complexity before optimising, and handling all-negative arrays.

**Seven day practice plan discussed**

Day 1: collections, strings and equality. Day 2: objects, validation and exceptions. Day 3: Streams, grouping and financial values. Day 4: unit tests and testable design. Day 5: API automation and BDD. Day 6: asynchronous systems and code review. Day 7: a timed mock and review of weak areas. The suggested routine was revision, independent coding, tests and an explanation aloud.

For each coding exercise, restate the requirement, clarify ambiguous behaviour, walk through an example, select a data structure, implement a simple solution, test boundaries and discuss complexity and maintainability.

The readiness discussion recommended attempting fresh strings, arrays and collections exercises independently under a 25-minute limit, with compilation, edge-case tests and an explanation of complexity. The recommendation to request additional time was based on the practice shown at that point, not a prediction of the interview outcome.

**Role and source context**

The practice was tailored to the Test Director / Head of Test Automation context, with emphasis on Java, trading data, automation design, BDD, APIs, CI/CD and distributed-system reliability. Public interview guides were treated as topic leads rather than proof of exact director-round questions. PracHub displayed HTML parsing and maximum-subarray prompts as practice material. Glassdoor could not be independently retrieved during the check. A separate SMBC developer vacancy supported the relevance of Java, APIs, concurrency and automated testing, but was not the target role's interview specification.


### 3.05 Reference links

- Java Object: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/Object.html
- Java Objects utilities: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/Objects.html
- Java Collection: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/Collection.html
- Java List: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/List.html
- Java Map: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/Map.html
- Java Thread: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/Thread.html
- Java concurrency package: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/package-summary.html
- Java AtomicLong: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/atomic/AtomicLong.html
- Java ThreadLocal: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/ThreadLocal.html
- Java BigDecimal: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/math/BigDecimal.html
- Java HashMap: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/HashMap.html
- Java Streams: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/stream/Stream.html
- Stream package guidance: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/stream/package-summary.html
- Java Collectors: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/stream/Collectors.html
- Java ConcurrentHashMap: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/ConcurrentHashMap.html
- Java ExecutorService: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/ExecutorService.html
- Java TreeMap: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/TreeMap.html
- jsoup selectors: https://jsoup.org/cookbook/extracting-data/selector-syntax
- jsoup installation: https://jsoup.org/download
- JUnit guide: https://docs.junit.org/current/user-guide/
- Cucumber Gherkin: https://cucumber.io/docs/gherkin/reference/
- Cucumber step design: https://cucumber.io/docs/guides/anti-patterns/
- OneCompiler: https://onecompiler.com/java
- PracHub practice guide: https://prachub.com/interview-guide/smbc-group-software-engineer-interview-questions-guide-2026
- Related SMBC Java vacancy: https://careers.smbcgroup.com/smbc/job/New-York-Senior-Java-Developer-NY-10172/1421150300/

