import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    static final class OrderKey {
        private final String id;
        OrderKey(String id) {
            this.id = Objects.requireNonNull(id, "id");
        }
        @Override public boolean equals(Object other) {
            if (this == other) return true;
            if (!(other instanceof OrderKey)) return false;
            return Objects.equals(id, ((OrderKey) other).id);
        }
        @Override public int hashCode() { return Objects.hash(id); }
        @Override public String toString() { return "OrderKey[" + id + "]"; }
    }

    record OrderTags(String orderId, List<String> tags) {
        OrderTags {
            Objects.requireNonNull(orderId, "orderId");
            tags = List.copyOf(tags);
        }
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        OrderKey a = new OrderKey("O1");
        OrderKey b = new OrderKey("O1");
        check(a != b, "Two constructions produce distinct identities");
        check(a.equals(b), "ID-based logical equality");
        check(a.hashCode() == b.hashCode(), "Equal keys have equal hashes");
        check(new HashSet<>(List.of(a, b)).size() == 1, "HashSet uses equality");
        check(a.getClass() == OrderKey.class, "Runtime type");
        check(a.toString().equals("OrderKey[O1]"), "Diagnostic representation");
        check(Objects.equals(null, null), "Two null references");
        check(!Objects.equals(null, a), "Null versus object");
        check(Objects.hashCode(null) == 0, "Null-safe hashCode");
        check(Objects.requireNonNull(a, "order") == a, "Validation returns the original reference");
        try {
            Objects.requireNonNull(null, "order");
            throw new AssertionError("Expected NullPointerException");
        } catch (NullPointerException expected) {
            check(expected.getMessage().equals("order"), "Missing reference rejected");
        }
        check(Objects.requireNonNullElse(null, "UNKNOWN").equals("UNKNOWN"), "Fallback value");
        check(Objects.requireNonNullElseGet("AAPL", () -> {
            throw new AssertionError("Supplier should be skipped");
        }).equals("AAPL"), "Fallback supplier is lazy");
        check(Objects.isNull(null) && Objects.nonNull(a), "Null predicates");
        check(Objects.toString(null, "missing").equals("missing"), "Diagnostic fallback");
        check(Objects.deepEquals(new int[]{1, 2}, new int[]{1, 2}), "Array content comparison");
        List<String> mutableTags = new ArrayList<>(List.of("BUY"));
        OrderTags order = new OrderTags("O1", mutableTags);
        mutableTags.add("EXTERNAL_CHANGE");
        check(order.tags().equals(List.of("BUY")), "Input changes do not affect the record copy");
        try {
            order.tags().add("CHANGE");
            throw new AssertionError("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            check(true, "Returned tags are unmodifiable");
        }
        System.out.println("PASS: " + checks + " checks");
    }
}
