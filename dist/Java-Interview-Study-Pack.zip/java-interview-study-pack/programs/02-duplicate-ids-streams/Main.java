import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static List<String> findDuplicateTradeIds(List<String> tradeIds) {
        if (tradeIds == null) {
            throw new IllegalArgumentException("List must not be null");
        }
        if (tradeIds.stream().anyMatch(id -> id == null || id.isBlank())) {
            throw new IllegalArgumentException("IDs must not be null or blank");
        }
        List<String> ids = new ArrayList<>(tradeIds);
        Map<String, List<Integer>> positions = IntStream.range(0, ids.size())
                .boxed()
                .collect(Collectors.groupingBy(ids::get));

        return positions.entrySet().stream()
                .filter(entry -> entry.getValue().size() > 1)
                .sorted(Comparator.comparingInt(entry -> entry.getValue().get(1)))
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        check(findDuplicateTradeIds(List.of("T1", "T2", "T2", "T3", "T1", "T2"))
                .equals(List.of("T2", "T1")), "Second occurrence order");
        check(findDuplicateTradeIds(List.of()).isEmpty(), "Empty input");
        check(findDuplicateTradeIds(new LinkedList<>(List.of("B", "A", "A", "B")))
                .equals(List.of("A", "B")), "LinkedList input");
        check(findDuplicateTradeIds(List.of("A", "A", "A")).equals(List.of("A")), "One output per ID");
        rejects(() -> findDuplicateTradeIds(null));
        rejects(() -> findDuplicateTradeIds(Arrays.asList("T1", null)));
        rejects(() -> findDuplicateTradeIds(List.of(" ")));
        System.out.println("PASS: " + checks + " checks");
    }
}
