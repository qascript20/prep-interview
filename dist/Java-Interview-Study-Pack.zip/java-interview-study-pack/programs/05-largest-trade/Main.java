import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    static class Trade {
        final String symbol;
        final int quantity;
        Trade(String symbol, int quantity) {
            this.symbol = symbol;
            this.quantity = quantity;
        }
    }

    public static Trade findLargestTrade(List<Trade> trades) {
        Trade largest = null;
        for (Trade trade : trades) {
            if (largest == null || trade.quantity > largest.quantity) {
                largest = trade;
            }
        }
        return largest;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        Trade firstWinner = new Trade("MSFT", 250);
        Trade laterTie = new Trade("AMZN", 250);
        List<Trade> trades = List.of(new Trade("AAPL", 100), firstWinner,
                new Trade("GOOG", 150), laterTie);
        check(findLargestTrade(trades) == firstWinner, "First object wins tie");
        check(findLargestTrade(List.of()) == null, "Empty list");
        check(findLargestTrade(List.of(laterTie)) == laterTie, "Single object");
        check(findLargestTrade(List.of(new Trade("A", -10), new Trade("B", -5))).quantity == -5,
                "Algorithm does not assume a zero starting maximum");
        System.out.println(findLargestTrade(trades).symbol);
        System.out.println("PASS: " + checks + " checks");
    }
}
