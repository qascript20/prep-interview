import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    static final class Order {
        private final String orderId;
        private final String symbol;
        private final int quantity;
        private final BigDecimal price;

        public Order(String orderId, String symbol, int quantity, BigDecimal price) {
            if (orderId == null || orderId.isBlank()) {
                throw new IllegalArgumentException("Order ID is required");
            }
            if (symbol == null || symbol.isBlank()) {
                throw new IllegalArgumentException("Symbol is required");
            }
            if (quantity <= 0) {
                throw new IllegalArgumentException("Quantity must be positive");
            }
            if (price == null || price.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException("Price must be positive");
            }
            this.orderId = orderId;
            this.symbol = symbol;
            this.quantity = quantity;
            this.price = price;
        }
        public String getOrderId() { return orderId; }
        public String getSymbol() { return symbol; }
        public int getQuantity() { return quantity; }
        public BigDecimal getPrice() { return price; }
        public BigDecimal getNotional() {
            return price.multiply(BigDecimal.valueOf(quantity));
        }
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        Order order = new Order("O1", "AAPL", 10, new BigDecimal("100.25"));
        check(order.getOrderId().equals("O1"), "ID getter");
        check(order.getSymbol().equals("AAPL"), "Symbol getter");
        check(order.getQuantity() == 10, "Quantity getter");
        check(order.getPrice().compareTo(new BigDecimal("100.25")) == 0, "Price getter");
        check(order.getNotional().compareTo(new BigDecimal("1002.50")) == 0, "Notional");
        rejects(() -> new Order(null, "AAPL", 1, BigDecimal.ONE));
        rejects(() -> new Order(" ", "AAPL", 1, BigDecimal.ONE));
        rejects(() -> new Order("O1", " ", 1, BigDecimal.ONE));
        rejects(() -> new Order("O1", null, 1, BigDecimal.ONE));
        rejects(() -> new Order("O1", "AAPL", 0, BigDecimal.ONE));
        rejects(() -> new Order("O1", "AAPL", -1, BigDecimal.ONE));
        rejects(() -> new Order("O1", "AAPL", 1, null));
        rejects(() -> new Order("O1", "AAPL", 1, BigDecimal.ZERO));
        rejects(() -> new Order("O1", "AAPL", 1, new BigDecimal("-1")));
        System.out.println(order.getNotional());
        System.out.println("PASS: " + checks + " checks");
    }
}
