#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p classes
javac --release 17 -cp 'lib/*' -d classes TradeBlotter.java BlotterChecks.java
java -cp 'classes:lib/*' BlotterChecks
