import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.math.BigDecimal;
import java.util.*;

/** Java 17+. All rows must belong to the same currency and snapshot. */
public final class TradeBlotter {
    public enum Side { BUY, SELL }
    public enum Status { NEW, PENDING, PARTIALLY_FILLED, EXECUTED, CANCELLED, REJECTED }

    public record Trade(String id, String symbol, Side side, Status status,
                        BigDecimal price, BigDecimal quantity) {
        public Trade {
            if (id == null || id.isBlank() || symbol == null || symbol.isBlank()) {
                throw new IllegalArgumentException("Trade ID and symbol are required");
            }
            Objects.requireNonNull(side, "side");
            Objects.requireNonNull(status, "status");
            Objects.requireNonNull(price, "price");
            Objects.requireNonNull(quantity, "quantity");
            if (quantity.signum() <= 0) {
                throw new IllegalArgumentException("Quantity must be positive");
            }
        }

        public BigDecimal notional() {
            return price.multiply(quantity);
        }
    }

    public static final class HtmlTradeParser {
        private static final Set<String> REQUIRED = Set.of(
                "trade id", "symbol", "side", "status", "price", "quantity");

        public List<Trade> parse(String html, String tableSelector) {
            if (html == null || html.isBlank()) {
                throw new IllegalArgumentException("HTML is required");
            }
            if (tableSelector == null || tableSelector.isBlank()) {
                throw new IllegalArgumentException("Table selector is required");
            }

            Elements matches = Jsoup.parse(html).select(tableSelector);
            if (matches.size() != 1 || !matches.first().tagName().equals("table")) {
                throw new IllegalArgumentException("Selector must identify exactly one table");
            }
            Element table = matches.first();
            // This adapter deliberately supports simple tables, not nested or merged cells.
            if (!table.select("td table, th table, [colspan], [rowspan]").isEmpty()) {
                throw new IllegalArgumentException("Nested tables and merged cells are unsupported");
            }
            Elements headerRows = table.select("thead > tr");
            if (headerRows.size() != 1) {
                throw new IllegalArgumentException("Exactly one header row is required");
            }
            Elements headers = headerRows.first().children();
            Map<String, Integer> columns = new HashMap<>();
            for (int i = 0; i < headers.size(); i++) {
                String name = headers.get(i).text().strip().toLowerCase(Locale.ROOT);
                if (!headers.get(i).tagName().equals("th") || name.isBlank()
                        || columns.putIfAbsent(name, i) != null) {
                    throw new IllegalArgumentException("Invalid or duplicate table header: " + name);
                }
            }
            if (!columns.keySet().containsAll(REQUIRED)) {
                Set<String> missing = new TreeSet<>(REQUIRED);
                missing.removeAll(columns.keySet());
                throw new IllegalArgumentException("Missing headers: " + missing);
            }

            List<Trade> trades = new ArrayList<>();
            Set<String> ids = new HashSet<>();
            Elements rows = table.select("tbody > tr");
            for (int i = 0; i < rows.size(); i++) {
                try {
                    Elements cells = rows.get(i).children();
                    if (cells.size() != headers.size()
                            || cells.stream().anyMatch(cell -> !cell.tagName().equals("td"))) {
                        throw new IllegalArgumentException("Cell count or structure differs from header");
                    }
                    Trade trade = new Trade(
                            text(cells, columns, "trade id"),
                            text(cells, columns, "symbol"),
                            Side.valueOf(text(cells, columns, "side").toUpperCase(Locale.ROOT)),
                            Status.valueOf(text(cells, columns, "status").toUpperCase(Locale.ROOT)),
                            new BigDecimal(text(cells, columns, "price")),
                            new BigDecimal(text(cells, columns, "quantity")));
                    if (!ids.add(trade.id())) {
                        throw new IllegalArgumentException("Duplicate trade ID: " + trade.id());
                    }
                    trades.add(trade);
                } catch (IllegalArgumentException e) {
                    throw new IllegalArgumentException("Blotter row " + (i + 1) + ": " + e.getMessage(), e);
                }
            }
            return List.copyOf(trades);
        }

        private static String text(Elements cells, Map<String, Integer> columns, String field) {
            String value = cells.get(columns.get(field)).text().strip();
            if (value.isBlank()) {
                throw new IllegalArgumentException("Blank field: " + field);
            }
            return value;
        }
    }

    public static BigDecimal totalExecutedBuyNotional(List<Trade> trades) {
        return trades.stream()
                .filter(trade -> trade.side() == Side.BUY && trade.status() == Status.EXECUTED)
                .map(Trade::notional)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
