import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class BlotterChecks {
    private static int checks;
    private static final TradeBlotter.HtmlTradeParser PARSER = new TradeBlotter.HtmlTradeParser();
    private static final String HEADERS = "<th>Trade ID</th><th>Symbol</th><th>Side</th><th>Status</th><th>Price</th><th>Quantity</th>";

    private static String table(String rows) {
        return "<table id='blotter'><thead><tr>" + HEADERS + "</tr></thead><tbody>" + rows + "</tbody></table>";
    }
    private static String row(String id, String side, String status, String price, String quantity) {
        return "<tr><td>" + id + "</td><td>AAPL</td><td>" + side + "</td><td>" + status
                + "</td><td>" + price + "</td><td>" + quantity + "</td></tr>";
    }
    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }
    private static void invalid(String html, String message) {
        checks++;
        try {
            PARSER.parse(html, "#blotter");
        } catch (IllegalArgumentException e) {
            if (!e.getMessage().contains(message)) throw new AssertionError(e);
            return;
        }
        throw new AssertionError("Expected rejection containing: " + message);
    }
    private static void total(String html, String expected) {
        BigDecimal value = TradeBlotter.totalExecutedBuyNotional(PARSER.parse(html, "#blotter"));
        check(value.compareTo(new BigDecimal(expected)) == 0, "Total: " + value + ", expected " + expected);
    }
    public static void main(String[] args) throws Exception {
        String example = Files.readString(Path.of("blotter.html"));
        List<TradeBlotter.Trade> trades = PARSER.parse(example, "#blotter");
        check(trades.size() == 4, "Parse all rows, not only matching rows");
        check(trades.get(0).id().equals("T1") && trades.get(0).symbol().equals("AAPL"), "Domain mapping");
        total(example, "1512.50");
        total(table(""), "0");
        total(table(row("T1", "SELL", "EXECUTED", "5", "10")), "0");
        total(table(row("T1", "BUY", "PENDING", "5", "10")), "0");
        total(table(row("T1", "BUY", "PARTIALLY_FILLED", "5", "10")), "0");
        total(table(row("T1", "BUY", "CANCELLED", "5", "10")), "0");
        total(table(row("T1", "BUY", "REJECTED", "5", "10")), "0");
        total(table(row("T1", " buy ", " executed ", "0.10", "3")), "0.30");
        total(table(row("T1", "BUY", "EXECUTED", "0.2", "1.5")), "0.30");
        total(table(row("T1", "BUY", "EXECUTED", "999999999999999999.99", "100")), "99999999999999999999.00");
        String reordered = "<table id='blotter'><thead><tr><th>Quantity</th><th>Status</th><th>Side</th><th>Symbol</th><th>Trade ID</th><th>Price</th></tr></thead><tbody><tr><td>10</td><td>EXECUTED</td><td>BUY</td><td>AAPL</td><td>T1</td><td>1.25</td></tr></tbody></table>";
        total(reordered, "12.50");
        String nestedText = table(row("T1", "BUY", "EXECUTED", "<span>1.25</span>", "10"));
        total(nestedText, "12.50");
        total("<table><tbody><tr><td>Unrelated table</td></tr></tbody></table>" + example, "1512.50");
        invalid(null, "HTML is required");
        invalid("", "HTML is required");
        invalid("<html></html>", "exactly one table");
        invalid(example + example, "exactly one table");
        invalid(example.replace("<th>Price</th>", "<th>Rate</th>"), "Missing headers");
        invalid(example.replace("<th>Price</th>", "<th>Side</th>"), "duplicate table header");
        invalid(table(row("T1", "BUY", "EXECUTED", "N/A", "10")), "Blotter row 1");
        invalid(table(row("T1", "BUY", "EXECUTED", "1,000.00", "10")), "Blotter row 1");
        invalid(table(row("T1", "BUY", "UNKNOWN", "10", "10")), "Blotter row 1");
        invalid(table(row("T1", "HOLD", "EXECUTED", "10", "10")), "Blotter row 1");
        invalid(table(row("T1", "BUY", "EXECUTED", "10", "0")), "Quantity must be positive");
        invalid(table(row("T1", "BUY", "EXECUTED", "10", "-1")), "Quantity must be positive");
        invalid(table(row("T1", "BUY", "EXECUTED", "", "10")), "Blank field: price");
        invalid(table(row("T1", "BUY", "EXECUTED", "10", "10") + row("T1", "BUY", "EXECUTED", "10", "10")), "Duplicate trade ID");
        invalid(table("<tr><td>T1</td></tr>"), "Cell count");
        invalid(example.replace("<td>T1</td>", "<td colspan='2'>T1</td>"), "merged cells");
        invalid(example.replace("<td>T1</td>", "<td><table><tr><td>T1</td></tr></table></td>"), "Nested tables");
        System.out.println("PASS: " + checks + " checks");
        System.out.println("Executed BUY notional: " + TradeBlotter.totalExecutedBuyNotional(trades).toPlainString());
    }
}
