# Java blotter parser interview practice

This Java 17+ example extracts trades from an HTML table and calculates the total price times quantity for EXECUTED BUY orders. The HTML parser and calculation are independent, so the calculation can also accept trades from a future JSON adapter.

## Run

Java 17+ and its compiler must be installed. The jsoup 1.24.1 dependency is included in lib; its licence is included in the jar.

From this extracted directory on macOS or Linux:

```sh
sh run.sh
```

Expected output:

```text
PASS: 32 checks
Executed BUY notional: 1512.50
```

## Read the code

1. TradeBlotter.Trade is the domain object. A Java record defines its fields, accessors and constructor. The compact constructor validates required values.
2. HtmlTradeParser.parse accepts HTML and a CSS selector. It requires one simple table, maps the headers to column indexes and extracts every body row.
3. Text is trimmed, enum labels are normalised with Locale.ROOT, and price and quantity are constructed directly as BigDecimal values.
4. totalExecutedBuyNotional filters the domain objects by side and status, multiplies price by quantity, then sums from BigDecimal.ZERO. It does not depend on HTML.
5. BlotterChecks exercises mapping, filtering, precision, reordered columns and error handling without a test framework. Reimplement selected checks as JUnit tests for additional practice.

## Input contract

- All trades belong to one currency. Aggregate separately per currency if that changes.
- The table contains one thead header row and tbody data rows. The required header labels are Trade ID, Symbol, Side, Status, Price and Quantity; their order may change. Extra columns are allowed if each data row matches the header's width.
- The example expects a complete snapshot of the relevant rows. It does not load a browser, run JavaScript or traverse UI pagination. Obtain the rendered DOM using Selenium or Playwright when necessary.
- No nested tables, rowspan, colspan, placeholder rows or summary rows occur inside tbody. Unsupported structures fail clearly rather than being silently skipped.
- Trade IDs are unique within this snapshot. Duplicate IDs fail to prevent accidental double counting. If the real UI uses one row per fill, agree a different identity rule before adapting the parser.
- Price and quantity are plain decimal strings with a dot decimal separator. Grouping commas, currency symbols and locale-specific formatting are rejected; they need an explicit formatting contract to be parsed safely.
- Quantity must be positive. Fractional quantities are supported. Signed prices are allowed; restrict them only if the instrument's business rules require that.
- Supported statuses are NEW, PENDING, PARTIALLY_FILLED, EXECUTED, CANCELLED and REJECTED. Unknown labels fail. A partially filled order is excluded under this exercise's exact EXECUTED rule.
- No rounding is applied during calculation. Agree a separate rounding rule if the API returns a rounded amount.

## Suggested JSON follow-up

The summary.json file is a sample API fixture for the next exercise. JSON parsing and live HTTP calls are deliberately outside this HTML-parser example.

Implement a separate JSON adapter, for example with Jackson, to read currency and executedBuyNotional. Compare its BigDecimal total with the calculated UI total using compareTo() == 0, so 1512.5 and 1512.50 are numerically equal.

Before comparing a live API and UI, confirm matching currency, filters, pagination coverage, notional units and snapshot or as-of time. An aggregate match alone does not prove every individual trade matches.

## Further interview exercises

1. Parse an API list of trades into the same Trade type and compare each trade by ID.
2. Add currency to Trade and return totals grouped by currency.
3. Add a Selenium adapter that waits for a ready indicator and captures the table's outerHTML.
4. Return structured parse errors carrying row number, trade ID and field name.
5. Add a configurable header alias map for Price versus Execution Price.

## Dependency

For a Maven project:

```xml
<dependency>
  <groupId>org.jsoup</groupId>
  <artifactId>jsoup</artifactId>
  <version>1.24.1</version>
</dependency>
```

For a Gradle project:

```groovy
repositories { mavenCentral() }
dependencies { implementation 'org.jsoup:jsoup:1.24.1' }
```

Sources: https://jsoup.org/cookbook/extracting-data/selector-syntax and https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/math/BigDecimal.html
