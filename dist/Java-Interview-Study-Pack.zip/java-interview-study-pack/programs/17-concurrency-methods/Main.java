import java.math.*;
import java.util.*;
import java.util.stream.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class Main {
    // These examples simulate trading tasks; they do not call an external service.

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) throws Exception {
        int workers = 4;
        int incrementsPerWorker = 2000;
        ConcurrentHashMap<String, Long> counts = new ConcurrentHashMap<>();
        AtomicLong processed = new AtomicLong();
        LongAdder metric = new LongAdder();
        CountDownLatch start = new CountDownLatch(1);
        ExecutorService pool = Executors.newFixedThreadPool(workers);
        try {
            List<Future<Void>> jobs = new ArrayList<>();
            for (int worker = 0; worker < workers; worker++) {
                jobs.add(pool.submit(() -> {
                    start.await();
                    for (int i = 0; i < incrementsPerWorker; i++) {
                        counts.merge("AAPL", 1L, Long::sum);
                        processed.incrementAndGet();
                        metric.increment();
                    }
                    return null;
                }));
            }
            start.countDown();
            for (Future<Void> job : jobs) job.get(5, TimeUnit.SECONDS);
            long expected = (long) workers * incrementsPerWorker;
            check(counts.get("AAPL").equals(expected), "Atomic keyed updates after all workers finish");
            check(processed.get() == expected, "AtomicLong updates");
            check(metric.sum() == expected, "LongAdder read after workers finish");
            check(start.getCount() == 0, "Start latch released");

            AtomicLong sequence = new AtomicLong(10);
            check(sequence.compareAndSet(10, 11), "Successful compare-and-set");
            check(!sequence.compareAndSet(10, 12), "Stale expected value rejected");
            check(sequence.getAndIncrement() == 11 && sequence.get() == 12, "Return old value then increment");
            check(sequence.addAndGet(3) == 15, "Atomic addition");

            CompletableFuture<BigDecimal> credit = CompletableFuture.supplyAsync(
                () -> new BigDecimal("100.25"), pool);
            CompletableFuture<BigDecimal> market = CompletableFuture.supplyAsync(
                () -> new BigDecimal("50.00"), pool);
            BigDecimal combined = credit.thenCombine(market, BigDecimal::add).get(5, TimeUnit.SECONDS);
            check(combined.compareTo(new BigDecimal("150.25")) == 0, "Combine independent asynchronous values");

            Future<Integer> failed = pool.submit(() -> {
                throw new IllegalArgumentException("Simulated risk failure");
            });
            try {
                failed.get(5, TimeUnit.SECONDS);
                throw new AssertionError("Expected ExecutionException");
            } catch (ExecutionException expectedFailure) {
                check(expectedFailure.getCause() instanceof IllegalArgumentException, "Observe worker failure");
            }
            pool.shutdown();
            check(pool.awaitTermination(5, TimeUnit.SECONDS), "Owned executor terminates");
        } finally {
            start.countDown();
            pool.shutdownNow();
        }

        BlockingQueue<String> queue = new ArrayBlockingQueue<>(2);
        check(queue.offer("E1") && queue.offer("E2"), "Bounded queue accepts within capacity");
        check(!queue.offer("E3"), "Queue reports full capacity");
        check(queue.poll().equals("E1"), "FIFO queue order");
        check(queue.take().equals("E2"), "Take an available element");
        check(queue.poll() == null, "Empty nonblocking poll");

        ThreadLocal<String> context = new ThreadLocal<>();
        ExecutorService singleWorker = Executors.newSingleThreadExecutor();
        try {
            Future<String> first = singleWorker.submit(() -> {
                context.set("ORDER-O1");
                try { return context.get(); }
                finally { context.remove(); }
            });
            check(first.get(5, TimeUnit.SECONDS).equals("ORDER-O1"), "Task sees its context");
            Future<String> next = singleWorker.submit(context::get);
            check(next.get(5, TimeUnit.SECONDS) == null, "Reused worker does not retain prior context");
            singleWorker.shutdown();
            check(singleWorker.awaitTermination(5, TimeUnit.SECONDS), "Context executor terminates");
        } finally {
            singleWorker.shutdownNow();
        }
        System.out.println("PASS: " + checks + " checks");
    }
}
