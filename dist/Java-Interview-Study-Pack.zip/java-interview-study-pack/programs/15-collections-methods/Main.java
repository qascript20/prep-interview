import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    private static void expectUnsupported(Runnable operation) {
        try {
            operation.run();
            throw new AssertionError("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            check(true, "Unsupported mutation rejected");
        }
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        Map<String, Integer> counts = new HashMap<>();
        counts.merge("AAPL", 1, Integer::sum);
        counts.merge("AAPL", 1, Integer::sum);
        check(counts.get("AAPL").equals(2), "merge combines counts");
        check(counts.getOrDefault("MSFT", 0) == 0 && !counts.containsKey("MSFT"), "Fallback does not insert");
        counts.putIfAbsent("AAPL", 99);
        check(counts.get("AAPL").equals(2), "Existing value preserved");
        counts.compute("AAPL", (symbol, old) -> old + 5);
        check(counts.get("AAPL").equals(7), "compute updates mapping");
        check(counts.replace("AAPL", 7, 8), "Conditional replacement");
        check(!counts.remove("AAPL", 7), "Conditional removal checks the value");
        check(counts.remove("AAPL", 8), "Conditional removal succeeds");
        Map<String, List<String>> ids = new HashMap<>();
        ids.computeIfAbsent("AAPL", symbol -> new ArrayList<>()).add("T1");
        ids.computeIfAbsent("AAPL", symbol -> new ArrayList<>()).add("T2");
        check(ids.get("AAPL").equals(List.of("T1", "T2")), "Create then reuse a bucket");
        Set<String> keys = ids.keySet();
        ids.put("MSFT", new ArrayList<>());
        check(keys.contains("MSFT"), "keySet is a backed view");
        List<Integer> integers = new ArrayList<>(List.of(1, 2, 1));
        integers.remove(1);
        check(integers.equals(List.of(1, 1)), "remove(int) removes an index");
        integers.remove(Integer.valueOf(1));
        check(integers.equals(List.of(1)), "remove(Integer) removes a value");
        List<String> backing = new ArrayList<>(List.of("T1"));
        List<String> view = Collections.unmodifiableList(backing);
        List<String> snapshot = List.copyOf(backing);
        backing.add("T2");
        check(view.size() == 2 && snapshot.size() == 1, "View versus snapshot");
        expectUnsupported(() -> view.add("T3"));
        expectUnsupported(() -> snapshot.add("T3"));
        List<String> fixed = Arrays.asList("T1", "T2");
        fixed.set(0, "T0");
        check(fixed.get(0).equals("T0"), "Fixed-size list supports replacement");
        expectUnsupported(() -> fixed.add("T3"));
        check(new ArrayList<>(new LinkedHashSet<>(List.of("T2", "T1", "T2")))
                .equals(List.of("T2", "T1")), "Ordered deduplication");
        List<Integer> filtered = new ArrayList<>(List.of(1, 2, 3, 4));
        filtered.removeIf(value -> value % 2 == 0);
        check(filtered.equals(List.of(1, 3)), "removeIf");
        NavigableMap<Long, Long> bids = new TreeMap<>();
        bids.put(10000L, 10L);
        bids.put(10025L, 20L);
        check(bids.lastEntry().getKey().equals(10025L), "Highest bid");
        check(bids.floorEntry(10010L).getKey().equals(10000L), "Neighbouring price");
        Deque<String> events = new ArrayDeque<>();
        events.offerLast("E1");
        events.offerLast("E2");
        check(events.pollFirst().equals("E1"), "FIFO removal");
        PriorityQueue<Integer> smallestFirst = new PriorityQueue<>();
        smallestFirst.addAll(List.of(30, 10, 20));
        check(smallestFirst.poll() == 10, "Priority queue head");
        BigDecimal x = new BigDecimal("10.0");
        BigDecimal y = new BigDecimal("10.00");
        check(new HashSet<>(List.of(x, y)).size() == 2, "Hash equality sees different scales");
        check(new TreeSet<>(List.of(x, y)).size() == 1, "Sorted equality uses comparison");
        check(Arrays.asList(new int[]{1, 2}).size() == 1, "Primitive array is one list element");
        check(Arrays.stream(new int[]{1, 2}).boxed().toList().equals(List.of(1, 2)), "Box primitive elements");
        System.out.println("PASS: " + checks + " checks");
    }
}
