import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static boolean isPalindrome(String text) {
        if (text == null) return false;
        int left = 0;
        int right = text.length() - 1;
        while (left < right) {
            char first = text.charAt(left);
            char last = text.charAt(right);
            if (first == ' ') {
                left++;
                continue;
            }
            if (last == ' ') {
                right--;
                continue;
            }
            if (Character.toLowerCase(first) != Character.toLowerCase(last)) return false;
            left++;
            right--;
        }
        return true;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        String[] inputs = {"madam", "Race car", "Never odd or even", "Java", "", null, "   ", " a ", " a b "};
        boolean[] expected = {true, true, true, false, true, false, true, true, false};
        for (int i = 0; i < inputs.length; i++) {
            check(isPalindrome(inputs[i]) == expected[i], "Palindrome input: " + inputs[i]);
        }
        System.out.println("PASS: " + checks + " checks");
    }
}
