import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    static class Trade {
        final String symbol;
        final int quantity;
        Trade(String symbol, int quantity) {
            this.symbol = symbol;
            this.quantity = quantity;
        }
    }

    public static Map<String, Integer> totalQuantityBySymbol(List<Trade> trades) {
        Map<String, Integer> totals = new HashMap<>();
        for (Trade trade : trades) {
            totals.put(trade.symbol,
                    totals.getOrDefault(trade.symbol, 0) + trade.quantity);
        }
        return totals;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        List<Trade> trades = List.of(new Trade("AAPL", 100), new Trade("MSFT", 50),
                new Trade("AAPL", 200), new Trade("MSFT", 25), new Trade("GOOG", 10));
        check(totalQuantityBySymbol(trades).equals(Map.of("AAPL", 300, "MSFT", 75, "GOOG", 10)), "Totals");
        check(totalQuantityBySymbol(List.of()).isEmpty(), "Empty input");
        check(totalQuantityBySymbol(List.of(new Trade("AAPL", 5))).get("AAPL") == 5, "Single trade");
        System.out.println(totalQuantityBySymbol(trades));
        System.out.println("PASS: " + checks + " checks");
    }
}
