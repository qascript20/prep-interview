import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static List<String> findDuplicateTradeIds(List<String> tradeIds) {
        if (tradeIds == null) {
            throw new IllegalArgumentException("Trade ID list must not be null");
        }
        Map<String, Integer> counts = new HashMap<>();
        List<String> duplicates = new ArrayList<>();
        for (String id : tradeIds) {
            if (id == null || id.isBlank()) {
                throw new IllegalArgumentException("Trade ID must not be null or blank");
            }
            int count = counts.getOrDefault(id, 0) + 1;
            counts.put(id, count);
            if (count == 2) {
                duplicates.add(id);
            }
        }
        return duplicates;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        List<String> input = Arrays.asList("T1", "T2", "T2", "T3", "T1", "T2");
        List<String> before = new ArrayList<>(input);
        check(findDuplicateTradeIds(input).equals(List.of("T2", "T1")), "Second occurrence ordering");
        check(input.equals(before), "Input remains unchanged");
        check(findDuplicateTradeIds(List.of()).isEmpty(), "Empty input");
        check(findDuplicateTradeIds(List.of("T1", "T2")).isEmpty(), "Unique IDs");
        check(findDuplicateTradeIds(List.of("T1", "T1", "T1")).equals(List.of("T1")), "Output once");
        check(findDuplicateTradeIds(List.of("T1", "t1", "t1", "T1")).equals(List.of("t1", "T1")), "Case sensitivity");
        rejects(() -> findDuplicateTradeIds(null));
        rejects(() -> findDuplicateTradeIds(Arrays.asList("T1", null)));
        rejects(() -> findDuplicateTradeIds(List.of("")));
        rejects(() -> findDuplicateTradeIds(List.of(" ")));
        System.out.println(findDuplicateTradeIds(input));
        System.out.println("PASS: " + checks + " checks");
    }
}
