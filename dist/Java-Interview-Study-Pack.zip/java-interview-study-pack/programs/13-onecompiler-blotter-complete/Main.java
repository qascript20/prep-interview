import java.math.BigDecimal;
import java.util.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main {

    enum Side { BUY, SELL }
    enum Status { EXECUTED, PENDING, CANCELLED, REJECTED }

    // A record is a compact data holder. Access fields with trade.price(), etc.
    record Trade(String id, String symbol, Side side, Status status,
                 BigDecimal price, BigDecimal quantity) {}

    public static List<Trade> parseTrades(String html) {
        if (html == null || html.isBlank()) {
            throw new IllegalArgumentException("HTML must not be null or blank");
        }

        Document document = Jsoup.parse(html);
        Element table = document.selectFirst("table#blotter");
        if (table == null) {
            throw new IllegalArgumentException("Blotter table is missing");
        }

        Elements rows = table.select("tbody > tr");
        List<Trade> trades = new ArrayList<>();

        for (Element row : rows) {
            Elements cells = row.select("td");
            if (cells.size() != 6) {
                throw new IllegalArgumentException("Each trade row must have six cells");
            }

            String id = cells.get(0).text().trim();
            String symbol = cells.get(1).text().trim();
            Side side = Side.valueOf(
                    cells.get(2).text().trim().toUpperCase(Locale.ROOT));
            Status status = Status.valueOf(
                    cells.get(3).text().trim().toUpperCase(Locale.ROOT));
            BigDecimal price = new BigDecimal(cells.get(4).text().trim());
            BigDecimal quantity = new BigDecimal(cells.get(5).text().trim());

            if (id.isBlank() || symbol.isBlank()) {
                throw new IllegalArgumentException("Trade ID and symbol are required");
            }

            Trade trade = new Trade(id, symbol, side, status, price, quantity);
            trades.add(trade);
        }

        return trades;
    }

    public static BigDecimal totalExecutedBuyNotional(List<Trade> trades) {
        return trades.stream()
                .filter(trade -> trade.side() == Side.BUY
                        && trade.status() == Status.EXECUTED)
                .map(trade -> trade.price().multiply(trade.quantity()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private static int passed;
    private static int totalChecks;

    private static void check(String description, boolean condition) {
        totalChecks++;
        if (condition) passed++;
        System.out.println((condition ? "PASS: " : "FAIL: ") + description);
    }

    public static void main(String[] args) {
        // Scope: one currency, fixed column order, no commas or currency symbols.
        // This fixture represents a rendered UI snapshot, not a live page.
        String html = """
            <table id="blotter">
              <thead><tr>
                <th>Trade ID</th><th>Symbol</th><th>Side</th>
                <th>Status</th><th>Price</th><th>Quantity</th>
              </tr></thead>
              <tbody>
                <tr><td>T1</td><td>AAPL</td><td>BUY</td><td>EXECUTED</td><td>100.25</td><td>10</td></tr>
                <tr><td>T2</td><td>MSFT</td><td>SELL</td><td>EXECUTED</td><td>50.00</td><td>20</td></tr>
                <tr><td>T3</td><td>GOOG</td><td>BUY</td><td>PENDING</td><td>12.00</td><td>5</td></tr>
                <tr><td>T4</td><td>AMZN</td><td>BUY</td><td>EXECUTED</td><td>25.50</td><td>20</td></tr>
              </tbody>
            </table>
            """;

        List<Trade> parsed = parseTrades(html);
        check("Parser extracts all four trades", parsed.size() == 4);
        check("First trade fields are mapped correctly", !parsed.isEmpty()
                && parsed.get(0).id().equals("T1")
                && parsed.get(0).symbol().equals("AAPL")
                && parsed.get(0).side() == Side.BUY
                && parsed.get(0).status() == Status.EXECUTED
                && parsed.get(0).price().compareTo(new BigDecimal("100.25")) == 0
                && parsed.get(0).quantity().compareTo(new BigDecimal("10")) == 0);

        BigDecimal actual = totalExecutedBuyNotional(parsed);
        BigDecimal expected = new BigDecimal("1512.50");
        check("UI total is 1512.50", actual.compareTo(expected) == 0);

        // Independent calculator checks let you practise TODO 2 before TODO 1.
        Trade buy = new Trade("B1", "AAPL", Side.BUY, Status.EXECUTED,
                new BigDecimal("0.10"), new BigDecimal("3"));
        Trade sell = new Trade("S1", "MSFT", Side.SELL, Status.EXECUTED,
                new BigDecimal("99"), new BigDecimal("10"));
        Trade pending = new Trade("P1", "GOOG", Side.BUY, Status.PENDING,
                new BigDecimal("99"), new BigDecimal("10"));

        check("Calculator includes an executed BUY exactly",
                totalExecutedBuyNotional(List.of(buy)).compareTo(new BigDecimal("0.30")) == 0);
        check("Calculator excludes SELL and PENDING orders",
                totalExecutedBuyNotional(List.of(buy, sell, pending))
                        .compareTo(new BigDecimal("0.30")) == 0);
        check("No matching trades returns zero",
                totalExecutedBuyNotional(List.of(sell, pending)).compareTo(BigDecimal.ZERO) == 0);
        check("Empty trade list returns zero",
                totalExecutedBuyNotional(List.of()).compareTo(BigDecimal.ZERO) == 0);
        check("Empty table returns no trades",
                parseTrades("<table id='blotter'><tbody></tbody></table>").isEmpty());

        System.out.println("Expected UI total: " + expected.toPlainString());
        System.out.println("Actual UI total:   " + actual.toPlainString());
        System.out.println("Checks passed: " + passed + "/" + totalChecks);
    }
}
