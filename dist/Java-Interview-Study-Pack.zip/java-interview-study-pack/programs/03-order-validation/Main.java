import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static List<String> validateOrder(String symbol, int quantity, BigDecimal price) {
        List<String> errors = new ArrayList<>();
        if (symbol == null || symbol.isBlank()) {
            errors.add("Symbol is required");
        }
        if (quantity <= 0) {
            errors.add("Quantity must be positive");
        }
        if (price == null || price.compareTo(BigDecimal.ZERO) <= 0) {
            errors.add("Price must be positive");
        }
        return errors;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        check(validateOrder("AAPL", 100, new BigDecimal("150.50")).isEmpty(), "Valid order");
        check(validateOrder("", 0, new BigDecimal("-10")).equals(List.of(
                "Symbol is required", "Quantity must be positive", "Price must be positive")), "All errors");
        check(validateOrder("AAPL", 10, null).equals(List.of("Price must be positive")), "Null price");
        check(validateOrder(null, -1, BigDecimal.ZERO).size() == 3, "All invalid boundaries");
        check(validateOrder(" ", 1, BigDecimal.ONE).equals(List.of("Symbol is required")), "Blank symbol");
        System.out.println("PASS: " + checks + " checks");
    }
}
