import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static List<String> findMissingTrades(List<String> expected, List<String> actual) {
        Set<String> actualTrades = new HashSet<>(actual);
        List<String> missingTrades = new ArrayList<>();
        for (String trade : expected) {
            if (!actualTrades.contains(trade)) {
                missingTrades.add(trade);
            }
        }
        return missingTrades;
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        List<String> expected = Arrays.asList("T1", "T2", "T3", "T4");
        List<String> actual = Arrays.asList("T2", "T4", "T5");
        check(findMissingTrades(expected, actual).equals(List.of("T1", "T3")), "Missing IDs");
        check(expected.equals(List.of("T1", "T2", "T3", "T4")), "Expected unchanged");
        check(actual.equals(List.of("T2", "T4", "T5")), "Actual unchanged");
        check(findMissingTrades(List.of("T1", "T2"), List.of("T2", "T1")).isEmpty(), "All present");
        check(findMissingTrades(List.of("T1", "T2"), List.of()).equals(List.of("T1", "T2")), "Actual empty");
        check(findMissingTrades(List.of(), List.of("T1")).isEmpty(), "Expected empty");
        System.out.println("PASS: " + checks + " checks");
    }
}
