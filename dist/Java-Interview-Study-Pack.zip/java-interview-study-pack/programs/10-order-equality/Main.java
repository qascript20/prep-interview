import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    static final class Order {
        private final String orderId;
        private final String symbol;
        private final int quantity;
        private final BigDecimal price;
        public Order(String orderId, String symbol, int quantity, BigDecimal price) {
            this.orderId = orderId;
            this.symbol = symbol;
            this.quantity = quantity;
            this.price = price;
        }
        public String getOrderId() { return orderId; }
        public int getQuantity() { return quantity; }
        @Override
        public boolean equals(Object other) {
            if (this == other) return true;
            if (!(other instanceof Order)) return false;
            Order otherOrder = (Order) other;
            return Objects.equals(this.orderId, otherOrder.orderId);
        }
        @Override
        public int hashCode() {
            return Objects.hash(orderId);
        }
    }

    public static List<Order> removeDuplicates(List<Order> orders) {
        Set<Order> uniqueOrders = new LinkedHashSet<>(orders);
        return new ArrayList<>(uniqueOrders);
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        Order first = new Order("O1", "AAPL", 10, new BigDecimal("100.25"));
        Order second = new Order("O2", "MSFT", 20, new BigDecimal("50.00"));
        Order duplicate = new Order("O1", "AAPL", 99, new BigDecimal("101.00"));
        List<Order> result = removeDuplicates(List.of(first, second, duplicate));
        check(first.equals(duplicate), "ID-based equality");
        check(duplicate.equals(first), "Symmetry");
        check(first.equals(first), "Reflexivity");
        check(!first.equals(null), "Null comparison");
        check(!first.equals("O1"), "Different type");
        check(!first.equals(second), "Different ID");
        check(first.hashCode() == duplicate.hashCode(), "Equal values have equal hashes");
        check(result.size() == 2 && result.get(0) == first && result.get(1) == second,
                "Preserve first objects and their order");
        check(removeDuplicates(List.of()).isEmpty(), "Empty input");
        for (Order order : result) System.out.println(order.getOrderId() + " -> quantity " + order.getQuantity());
        System.out.println("PASS: " + checks + " checks");
    }
}
