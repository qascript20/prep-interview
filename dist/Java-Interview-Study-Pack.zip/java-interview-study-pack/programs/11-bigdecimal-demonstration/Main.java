import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    // This example demonstrates library methods rather than defining an algorithm.

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        BigDecimal a = new BigDecimal("10.50");
        BigDecimal b = new BigDecimal("2");
        check(a.add(b).compareTo(new BigDecimal("12.50")) == 0, "Addition");
        check(a.subtract(b).compareTo(new BigDecimal("8.50")) == 0, "Subtraction");
        check(a.multiply(b).compareTo(new BigDecimal("21.00")) == 0, "Multiplication");
        check(a.divide(b).compareTo(new BigDecimal("5.25")) == 0, "Terminating division");
        check(a.compareTo(b) > 0, "Numeric comparison");
        check(a.signum() == 1, "Positive sign");
        check(a.setScale(1, RoundingMode.HALF_UP).toPlainString().equals("10.5"), "Scale");
        check(a.scale() == 2 && a.precision() == 4, "Scale versus precision");
        check(a.toPlainString().equals("10.50"), "Plain decimal text");
        check(BigDecimal.ONE.divide(new BigDecimal("3"), 2, RoundingMode.HALF_UP)
                .toPlainString().equals("0.33"), "Rounded division");
        BigDecimal total = BigDecimal.ZERO;
        total.add(a);
        check(total.signum() == 0, "Discarded arithmetic result does not change total");
        total = total.add(a);
        check(total.compareTo(a) == 0, "Assign updated total");
        BigDecimal x = new BigDecimal("10.0");
        BigDecimal y = new BigDecimal("10.00");
        check(!x.equals(y) && x.compareTo(y) == 0, "Representation versus numeric equality");
        check(new BigDecimal("100.25").multiply(BigDecimal.valueOf(10))
                .compareTo(new BigDecimal("1002.50")) == 0, "Order notional");
        System.out.println("PASS: " + checks + " checks");
    }
}
