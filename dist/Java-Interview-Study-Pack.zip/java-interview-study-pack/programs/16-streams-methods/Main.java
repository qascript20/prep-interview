import java.math.*;
import java.util.*;
import java.util.stream.*;

public class Main {
    enum Side { BUY, SELL }
    enum Status { EXECUTED, PENDING }
    record Trade(String id, String symbol, Side side, Status status,
                 BigDecimal price, long quantity) {
        BigDecimal notional() {
            return price.multiply(BigDecimal.valueOf(quantity));
        }
    }

    private static int checks;

    private static void check(boolean condition, String description) {
        checks++;
        if (!condition) throw new AssertionError(description);
    }

    private static void rejects(Runnable action) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        List<Trade> trades = List.of(
            new Trade("T1", "AAPL", Side.BUY, Status.EXECUTED, new BigDecimal("100.25"), 10),
            new Trade("T2", "AAPL", Side.BUY, Status.EXECUTED, new BigDecimal("102.00"), 5),
            new Trade("T3", "AAPL", Side.SELL, Status.EXECUTED, new BigDecimal("105.00"), 20),
            new Trade("T4", "MSFT", Side.BUY, Status.EXECUTED, new BigDecimal("50.00"), 20),
            new Trade("T5", "AAPL", Side.BUY, Status.PENDING, new BigDecimal("99.00"), 10)
        );
        List<Trade> buys = trades.stream()
            .filter(t -> t.side() == Side.BUY && t.status() == Status.EXECUTED).toList();
        check(buys.size() == 3, "filter executed buys");
        check(buys.stream().map(Trade::id).toList().equals(List.of("T1", "T2", "T4")), "map to IDs");
        BigDecimal total = buys.stream().map(Trade::notional)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        check(total.compareTo(new BigDecimal("2512.50")) == 0, "Decimal reduction");
        Map<String, BigDecimal> bySymbol = buys.stream().collect(Collectors.groupingBy(
            Trade::symbol, Collectors.reducing(BigDecimal.ZERO, Trade::notional, BigDecimal::add)));
        check(bySymbol.get("AAPL").compareTo(new BigDecimal("1512.50")) == 0, "Downstream decimal reduction");
        check(bySymbol.get("MSFT").compareTo(new BigDecimal("1000.00")) == 0, "Other symbol total");
        Map<String, Long> quantities = buys.stream().collect(Collectors.groupingBy(
            Trade::symbol, Collectors.summingLong(Trade::quantity)));
        check(quantities.equals(Map.of("AAPL", 15L, "MSFT", 20L)), "Integral quantity grouping");
        Map<String, Long> counts = trades.stream().collect(Collectors.groupingBy(
            Trade::symbol, Collectors.counting()));
        check(counts.equals(Map.of("AAPL", 4L, "MSFT", 1L)), "Counting collector");
        List<String> largest = buys.stream()
            .sorted(Comparator.comparing(Trade::notional).reversed().thenComparing(Trade::id))
            .limit(2).map(Trade::id).toList();
        check(largest.equals(List.of("T1", "T4")), "Descending sort and limit");
        List<String> flat = List.of(List.of("E1", "E2"), List.of("E3")).stream()
            .flatMap(List::stream).toList();
        check(flat.equals(List.of("E1", "E2", "E3")), "flatMap batches");
        check(Stream.of("AAPL", "AAPL", "MSFT").distinct().count() == 2, "distinct");
        check(trades.stream().anyMatch(t -> t.status() == Status.PENDING), "anyMatch");
        check(Stream.<Trade>empty().allMatch(t -> t.quantity() > 0), "Empty allMatch");
        check(!Stream.<Trade>empty().anyMatch(t -> t.quantity() > 0), "Empty anyMatch");
        check(Stream.<Trade>empty().noneMatch(t -> t.quantity() > 0), "Empty noneMatch");
        check(trades.stream().max(Comparator.comparing(Trade::notional)).orElseThrow().id().equals("T3"), "max");
        Map<Boolean, List<Trade>> partitions = trades.stream().collect(
            Collectors.partitioningBy(t -> t.status() == Status.EXECUTED));
        check(partitions.get(true).size() == 4 && partitions.get(false).size() == 1, "partitioningBy");
        check(buys.stream().map(Trade::id).collect(Collectors.joining(",")).equals("T1,T2,T4"), "joining");
        check(buys.stream().mapToLong(Trade::quantity).sum() == 35, "Primitive stream sum");
        List<String> mutable = buys.stream().map(Trade::id).collect(Collectors.toCollection(ArrayList::new));
        mutable.add("T6");
        check(mutable.size() == 4, "Explicit mutable collection");
        try {
            buys.add(trades.get(0));
            throw new AssertionError("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            check(true, "Stream.toList is unmodifiable");
        }
        Map<String, Trade> indexed = trades.stream().collect(Collectors.toMap(Trade::id, t -> t));
        check(indexed.size() == 5, "toMap for unique IDs");
        try {
            Stream.of("AAPL", "AAPL").collect(Collectors.toMap(symbol -> symbol, symbol -> 1));
            throw new AssertionError("Expected duplicate-key failure");
        } catch (IllegalStateException expected) {
            check(true, "toMap requires a duplicate-key policy");
        }
        System.out.println("PASS: " + checks + " checks");
    }
}
